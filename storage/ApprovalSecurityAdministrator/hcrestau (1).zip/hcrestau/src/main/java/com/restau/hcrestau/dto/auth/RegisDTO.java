package com.restau.hcrestau.dto.auth;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class RegisDTO {

    @NotEmpty(message = "Nama Depan Tidak Boleh Kosong")
    @NotNull(message = "Nama Depan Tidak Boleh Kosong")
    @NotBlank(message = "Nama Depan Tidak Boleh Mengandung Spasi")
    private String namaDepan;

    @NotEmpty(message = "Nama Belakang Tidak Boleh Kosong")
    @NotNull(message = "Nama Belakang Tidak Boleh Kosong")
    @NotBlank(message = "Nama Belakang Tidak Boleh Mengandung Spasi")
    private String namaBelakang;

    @NotEmpty
    @NotNull
    @NotBlank(message = "Tidak Boleh Blank")
    @Pattern(regexp = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}\\b")
    private String email;

    @NotEmpty
    @NotNull
    @NotBlank(message = "Tidak Boleh Blank")
    @Pattern(regexp = "(?=.*[a-z])(?=.*[A-Z])[A-Za-z\\d]{6,}.*")
    private String pass;

    @NotNull
    private Long akses;

    public String getNamaDepan() {
        return namaDepan;
    }

    public void setNamaDepan(String namaDepan) {
        this.namaDepan = namaDepan;
    }

    public String getNamaBelakang() {
        return namaBelakang;
    }

    public void setNamaBelakang(String namaBelakang) {
        this.namaBelakang = namaBelakang;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public Long getAkses() {
        return akses;
    }

    public void setAkses(Long idAkses) {
        akses = idAkses;
    }
}
