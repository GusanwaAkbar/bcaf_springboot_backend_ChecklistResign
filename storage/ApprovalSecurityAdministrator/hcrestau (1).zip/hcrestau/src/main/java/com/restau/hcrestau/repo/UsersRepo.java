package com.restau.hcrestau.repo;

import com.restau.hcrestau.model.UsersModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UsersRepo extends JpaRepository<UsersModel,Long>, JpaSpecificationExecutor<UsersModel> {
    Optional<UsersModel> findTop1ByEmail(String mail);
    Optional<UsersModel> findTop1ById(Long id);

    Page<UsersModel> findByNamaDepanContainingIgnoreCase(Pageable pageable, String namaDepan);

    Page<UsersModel> findByNamaBelakangContainingIgnoreCase(Pageable pageable, String namaBelakang);

    Page<UsersModel> findByEmailContainingIgnoreCase(Pageable pageable, String email);

}
