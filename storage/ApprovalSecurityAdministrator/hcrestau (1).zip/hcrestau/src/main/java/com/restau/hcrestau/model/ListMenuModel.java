package com.restau.hcrestau.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "ListMenu")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "idListMenu")
public class ListMenuModel {

    @Column(name = "IdListMenu")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long idListMenu;

    @Column(name = "NamaMenu")
    private String namaMenu;

    @JsonIgnore
    @ManyToMany(mappedBy = "ltMenuModel")
    private List<AksesMenuModel> ltAksesMenuModel;

    //    Audit Trails
    @Column(name="CreatedBy",updatable = false)
    private String createdBy;
    @Column(name="CreatedDate", columnDefinition = "DATETIME default CURRENT_TIMESTAMP",updatable = false)
    private Date createdDate = new Date();
    @Column(name="UpdatedBy")
    private String updatedBy;
    @Column(name="UpdateDate", columnDefinition = "DATETIME default CURRENT_TIMESTAMP")
    private Date updatedDate;


    public Long getIdListMenu() {
        return idListMenu;
    }

    public void setIdListMenu(Long idListMenu) {
        this.idListMenu = idListMenu;
    }

    public String getNamaMenu() {
        return namaMenu;
    }

    public void setNamaMenu(String namaMenu) {
        this.namaMenu = namaMenu;
    }

    public List<AksesMenuModel> getLtAksesMenuModel() {
        return ltAksesMenuModel;
    }

    public void setLtAksesMenuModel(List<AksesMenuModel> ltAksesMenuModel) {
        this.ltAksesMenuModel = ltAksesMenuModel;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }
}
