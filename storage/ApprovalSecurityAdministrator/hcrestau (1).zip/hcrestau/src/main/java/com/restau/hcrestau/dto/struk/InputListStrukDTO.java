package com.restau.hcrestau.dto.struk;

import com.restau.hcrestau.model.ListAvailTabelModel;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class InputListStrukDTO {


    @NotNull(message = "No Tabel Tidak Boleh Null")
    private ListAvailTabelModel listAvailTabelModel;

    @NotNull(message = "Nama Kustomer Tidak Boleh Null")
    @NotEmpty(message = "Nama Kustomer Tidak Boleh Kosong")
    @NotBlank(message = "Nama Kustomer Tidak Boleh Mengandung Spasi")
    private String namaKustomer;

    public ListAvailTabelModel getListAvailTabelModel() {
        return listAvailTabelModel;
    }

    public void setListAvailTabelModel(ListAvailTabelModel listAvailTabelModel) {
        this.listAvailTabelModel = listAvailTabelModel;
    }

    public String getNamaKustomer() {
        return namaKustomer;
    }

    public void setNamaKustomer(String namaKustomer) {
        this.namaKustomer = namaKustomer;
    }
}
