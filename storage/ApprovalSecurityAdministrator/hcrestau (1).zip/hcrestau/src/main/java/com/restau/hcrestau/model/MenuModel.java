package com.restau.hcrestau.model;

import com.restau.hcrestau.constant.ScriptDBSQLServer;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Table(name = "Menu")
public class MenuModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdMenu")
    private Long idMenu;

    @Column(name = "NamaMenu",unique = true)
    private String namaMenu;

    @Column(name = "isAvailable")
    private Boolean isAvailable = true;

    @Column(name = "HargaMenu")
    private Double hargaMenu;

    @Column(name = "URLGambar")
    private String gambar;

    @Column(name = "IdGambar")
    private String idGambar;

    @ManyToOne
    @JoinColumn(name = "IdJenisMenu",foreignKey = @ForeignKey(name = "FK_MENU_TO_JENISMENU", foreignKeyDefinition = ScriptDBSQLServer.FK_JENISMENU))
    private JenisMenuModel jenisMenuModel;

    //    Audit Trails
    @Column(name="CreatedBy",updatable = false)
    private String createdBy;
    @Column(name="CreatedDate", columnDefinition = "DATETIME default CURRENT_TIMESTAMP",updatable = false)
    private Date createdDate  = new Date();;
    @Column(name="UpdatedBy")
    private String updatedBy;
    @Column(name="UpdateDate", columnDefinition = "DATETIME default CURRENT_TIMESTAMP")
    private Date updatedDate;

    public Long getIdMenu() {
        return idMenu;
    }

    public void setIdMenu(Long idMenu) {
        this.idMenu = idMenu;
    }

    public String getNamaMenu() {
        return namaMenu;
    }

    public void setNamaMenu(String namaMenu) {
        this.namaMenu = namaMenu;
    }

    public Boolean getAvailable() {
        return isAvailable;
    }

    public void setAvailable(Boolean available) {
        isAvailable = available;
    }

    public Double getHargaMenu() {
        return hargaMenu;
    }

    public void setHargaMenu(Double hargaMenu) {
        this.hargaMenu = hargaMenu;
    }

    public JenisMenuModel getJenisMenuModel() {
        return jenisMenuModel;
    }

    public void setJenisMenuModel(JenisMenuModel jenisMenuModel) {
        this.jenisMenuModel = jenisMenuModel;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getGambar() {
        return gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }

    public String getIdGambar() {
        return idGambar;
    }

    public void setIdGambar(String idGambar) {
        this.idGambar = idGambar;
    }
}
