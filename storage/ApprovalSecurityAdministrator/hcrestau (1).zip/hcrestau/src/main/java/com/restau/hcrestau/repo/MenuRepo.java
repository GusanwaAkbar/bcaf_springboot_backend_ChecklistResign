package com.restau.hcrestau.repo;

import com.restau.hcrestau.model.MenuModel;
import com.restau.hcrestau.model.UsersModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MenuRepo extends JpaRepository<MenuModel,Long>, JpaSpecificationExecutor<MenuModel> {
}
