package com.restau.hcrestau.controller;

import com.restau.hcrestau.dto.struk.InputListStrukDTO;
import com.restau.hcrestau.model.ListStrukModel;
import com.restau.hcrestau.service.ListStrukService;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/list-struk")
public class ListStrukController {

    @Autowired
    private ListStrukService listStrukService;

    @Autowired
    private ModelMapper modelMapper;

    private Map<String,String> mapSorting = new HashMap<String,String>();
    public ListStrukController() {
        mapSorting();
    }

    private void mapSorting()
    {
        mapSorting.put("id","id");
        mapSorting.put("noTabel","noTabel");
        mapSorting.put("namaKustomer","namaKustomer");
        mapSorting.put("idTransaksi","idTransaksi");
        mapSorting.put("totalBayar","totalBayar");
        mapSorting.put("pajak","pajak");
        mapSorting.put("totalBayarAkhir","totalBayarAkhir");
        mapSorting.put("isPaid","isPaid");
    }

    @PostMapping("/v1/create")
    public ResponseEntity<Object> save(@Valid @RequestBody InputListStrukDTO inputListStrukDTO, HttpServletRequest request){
        ListStrukModel listStrukModel = modelMapper.map(inputListStrukDTO, new TypeToken<ListStrukModel>() {}.getType());

        return listStrukService.save(listStrukModel,request);
    }

    //Edit if Paid
    @PutMapping("/v1/paid/{id}")
    public ResponseEntity<Object> editPaid(@PathVariable(value = "id") Long id,
                                           HttpServletRequest request){
        return listStrukService.editPaid(id,request);
    }

    @GetMapping("/v1/get-all")
    public ResponseEntity<Object> getAll(HttpServletRequest request){

        return listStrukService.getAll(request);
    }

    @GetMapping("/v1/get-struk/{page}/{sort}/{sortBy}")
    public ResponseEntity<Object> find(@PathVariable(value = "page") Integer page,
                                       @PathVariable(value = "sort") String sort,
                                       @PathVariable(value = "sortBy") String sortBy,
                                       @RequestParam("filterBy") String filterBy,
                                       @RequestParam("value") String value,
                                       @RequestParam("size") String size,
                                       HttpServletRequest request){
        Pageable pageable = null;
        page = page==null?0:page;
        sortBy = (sortBy==null || sortBy.equals(""))?"id":sortBy;
        sort   = (sort==null || sort.equals("") || sort.equals("asc"))?"asc":"desc";

        sortBy = mapSorting.get(sortBy);
        pageable = PageRequest.of(page,Integer.parseInt(size.equals("")?"10":size),
                sort.equals("desc")? Sort.by(sortBy).descending():Sort.by(sortBy));

        return listStrukService.find(pageable,filterBy,value,request);
    }

    @GetMapping("/v1/get-struk/{id}")
    public ResponseEntity<Object> getTransaksiByStrukId(@PathVariable(value = "id") Long id,
                                                        HttpServletRequest request){
        return listStrukService.getTransaksiByStrukId(id, request);
    }





}
