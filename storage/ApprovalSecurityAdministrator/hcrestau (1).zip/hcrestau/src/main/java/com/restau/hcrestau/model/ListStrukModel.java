package com.restau.hcrestau.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "ListStruk")
public class ListStrukModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "IdTabel")
    private ListAvailTabelModel listAvailTabelModel;

    @Column(name = "NamaKustomer")
    private String namaKustomer;

    @Column(name = "TotalBayar")
    private Double totalBayar = 0.0;

    @Column(name = "TanggalBayar")
    private Date tanggalBayar;

    @Column(name = "Pajak")
    private Double pajak = 0.0;

    @Column(name = "TotalBayarAkhir")
    private Double totalBayarAkhir = 0.0;

    @Column(name = "IsPaid")
    private Boolean isPaid = false;

    //Audit Trails
    @Column(name="CreatedBy",updatable = false)
    private String createdBy;
    @Column(name="CreatedDate", columnDefinition = "DATETIME default CURRENT_TIMESTAMP",updatable = false)
    private Date createdDate  = new Date();;
    @Column(name="UpdatedBy")
    private String updatedBy;
    @Column(name="UpdateDate", columnDefinition = "DATETIME default CURRENT_TIMESTAMP")
    private Date updatedDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ListAvailTabelModel getListAvailTabelModel() {
        return listAvailTabelModel;
    }

    public void setListAvailTabelModel(ListAvailTabelModel listAvailTabelModel) {
        this.listAvailTabelModel = listAvailTabelModel;
    }

    public String getNamaKustomer() {
        return namaKustomer;
    }

    public void setNamaKustomer(String namaKustomer) {
        this.namaKustomer = namaKustomer;
    }

    public Double getTotalBayar() {
        return totalBayar;
    }

    public void setTotalBayar(Double totalBayar) {
        this.totalBayar = totalBayar;
    }

    public Date getTanggalBayar() {
        return tanggalBayar;
    }

    public void setTanggalBayar(Date tanggalBayar) {
        this.tanggalBayar = tanggalBayar;
    }

    public Boolean getPaid() {
        return isPaid;
    }

    public void setPaid(Boolean paid) {
        isPaid = paid;
    }

    public Double getPajak() {
        return pajak;
    }

    public void setPajak(Double pajak) {
        this.pajak = pajak;
    }

    public Double getTotalBayarAkhir() {
        return totalBayarAkhir;
    }

    public void setTotalBayarAkhir(Double totalBayarAkhir) {
        this.totalBayarAkhir = totalBayarAkhir;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }
}
