package com.restau.hcrestau.dto.menu;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class ListMenuDTO {

    @NotEmpty(message = "Nama Menu Tidak Boleh Kosong")
    @NotNull(message = "Nama Menu Tidak Boleh Null")
    @NotBlank(message = "Nama Menu Tidak Boleh Mengandung Spasi")
    private String namaMenu;


    public String getNamaMenu() {
        return namaMenu;
    }

    public void setNamaMenu(String namaMenu) {
        this.namaMenu = namaMenu;
    }
}
