package com.restau.hcrestau.repo;

import com.restau.hcrestau.model.JenisMenuModel;
import com.restau.hcrestau.model.ListStrukModel;
import com.restau.hcrestau.model.ListTransaksiModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ListTransaksiRepo extends JpaRepository<ListTransaksiModel,Long> {

    Page<ListTransaksiModel> findByIdContainingIgnoreCase(Pageable pageable, Long idTransaksi);
    @Query(value = "SELECT * FROM RestAu.ListTransaksi WHERE IdStruk = ?1", nativeQuery = true)
    List<ListTransaksiModel> findByIdStruk(Long idStruk);

    //Search namaKustomer
    @Query("SELECT lt FROM ListTransaksiModel lt JOIN lt.listStrukModel ls WHERE ls.id = lt.listStrukModel.id")
    Page<ListTransaksiModel> findAllWithJoin(Pageable pageable);


}
