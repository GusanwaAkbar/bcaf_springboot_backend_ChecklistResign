package com.restau.hcrestau.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "ListTransaksi")
public class ListTransaksiModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdTransaksi")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "IdStruk")
    private ListStrukModel listStrukModel;

    @ManyToOne
    @JoinColumn(name = "IdMenu")
    private MenuModel menuModel;

    @ManyToOne
    @JoinColumn(name = "IdApprover")
    private UsersModel usersModel = null;

    @Column(name = "JumlahMenu")
    private Integer jumlahMenu;

    //dibutuhkan walau ada di menuModel, supaya ga ikutan update kalo ada harga yang update di menu
    @Column(name = "HargaMenu")
    private Double hargaMenu;

    @Column(name = "TotalHarga")
    private Double totalHarga = 0.0;

    @Column(name = "IsCooked")
    private Boolean isCooked = false;

    //Audit Trails
    @Column(name="CreatedBy",updatable = false)
    private String createdBy;
    @Column(name="CreatedDate", columnDefinition = "DATETIME default CURRENT_TIMESTAMP",updatable = false)
    private Date createdDate  = new Date();;
    @Column(name="UpdatedBy")
    private String updatedBy;
    @Column(name="UpdateDate", columnDefinition = "DATETIME default CURRENT_TIMESTAMP")
    private Date updatedDate;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ListStrukModel getListStrukModel() {
        return listStrukModel;
    }

    public void setListStrukModel(ListStrukModel listStrukModel) {
        this.listStrukModel = listStrukModel;
    }

    public MenuModel getMenuModel() {
        return menuModel;
    }

    public void setMenuModel(MenuModel menuModel) {
        this.menuModel = menuModel;
    }

    public UsersModel getUsersModel() {
        return usersModel;
    }

    public void setUsersModel(UsersModel usersModel) {
        this.usersModel = usersModel;
    }

    public Integer getJumlahMenu() {
        return jumlahMenu;
    }

    public void setJumlahMenu(Integer jumlahMenu) {
        this.jumlahMenu = jumlahMenu;
    }

    public Double getHargaMenu() {
        return hargaMenu;
    }

    public void setHargaMenu(Double hargaMenu) {
        this.hargaMenu = hargaMenu;
    }

    public Double getTotalHarga() {
        return totalHarga;
    }

    public void setTotalHarga(Double totalHarga) {
        this.totalHarga = totalHarga;
    }

    public Boolean getCooked() {
        return isCooked;
    }

    public void setCooked(Boolean cooked) {
        isCooked = cooked;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }
}
