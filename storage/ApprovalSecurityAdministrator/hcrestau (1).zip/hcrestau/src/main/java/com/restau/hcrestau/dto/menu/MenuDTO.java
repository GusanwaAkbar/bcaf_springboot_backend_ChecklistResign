package com.restau.hcrestau.dto.menu;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class MenuDTO {

    private String namaMenu;
    private Double hargaMenu;

    //Diambil dari Jenis Menu
    private Long jenisMenu;


    public MenuDTO(String namaMenu, Double hargaMenu, Long jenisMenu) {
        this.namaMenu = namaMenu;
        this.hargaMenu = hargaMenu;
        this.jenisMenu = jenisMenu;
    }

    public String getNamaMenu() {
        return namaMenu;
    }

    public void setNamaMenu(String namaMenu) {
        this.namaMenu = namaMenu;
    }

    public Double getHargaMenu() {
        return hargaMenu;
    }

    public void setHargaMenu(Double hargaMenu) {
        this.hargaMenu = hargaMenu;
    }


    public Long getJenisMenu() {
        return jenisMenu;
    }

    public void setJenisMenu(Long jenisMenu) {
        this.jenisMenu = jenisMenu;
    }
}
