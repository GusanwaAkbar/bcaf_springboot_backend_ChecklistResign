package com.restau.hcrestau.dto.struk;

public class GetDataStrukDTO {
    private Long id;
    private String namaKustomer;
    private Double totalBayar;
    private Double pajak;
    private Double totalBayarAkhir;

    //Diambil dari ListAvailTabel
    private Long idTabel;

    //Diambil dari Transaksi
    private long idTransaksi;
    private Double hargaMenu;
    private Integer jumlahMenu;
    private Double totalHarga;

    //Diambil dari Menu
    private String namaMenu;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNamaKustomer() {
        return namaKustomer;
    }

    public void setNamaKustomer(String namaKustomer) {
        this.namaKustomer = namaKustomer;
    }

    public Double getTotalBayar() {
        return totalBayar;
    }

    public void setTotalBayar(Double totalBayar) {
        this.totalBayar = totalBayar;
    }

    public Double getPajak() {
        return pajak;
    }

    public void setPajak(Double pajak) {
        this.pajak = pajak;
    }

    public Double getTotalBayarAkhir() {
        return totalBayarAkhir;
    }

    public void setTotalBayarAkhir(Double totalBayarAkhir) {
        this.totalBayarAkhir = totalBayarAkhir;
    }

    public Long getIdTabel() {
        return idTabel;
    }

    public void setIdTabel(Long idTabel) {
        this.idTabel = idTabel;
    }

    public long getIdTransaksi() {
        return idTransaksi;
    }

    public void setIdTransaksi(long idTransaksi) {
        this.idTransaksi = idTransaksi;
    }

    public Double getHargaMenu() {
        return hargaMenu;
    }

    public void setHargaMenu(Double hargaMenu) {
        this.hargaMenu = hargaMenu;
    }

    public Integer getJumlahMenu() {
        return jumlahMenu;
    }

    public void setJumlahMenu(Integer jumlahMenu) {
        this.jumlahMenu = jumlahMenu;
    }

    public Double getTotalHarga() {
        return totalHarga;
    }

    public void setTotalHarga(Double totalHarga) {
        this.totalHarga = totalHarga;
    }

    public String getNamaMenu() {
        return namaMenu;
    }

    public void setNamaMenu(String namaMenu) {
        this.namaMenu = namaMenu;
    }
}
