package com.restau.hcrestau.model;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Table(name = "JenisMenu")
public class JenisMenuModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdJenisMenu")
    private Long id;

    @Column(name = "NamaJenis")
    private String namaJenis;


    //    Audit Trails
    @Column(name="CreatedBy",updatable = false)
    private String createdBy;
    @Column(name="CreatedDate", columnDefinition = "DATETIME default CURRENT_TIMESTAMP",updatable = false)
    private Date createdDate = new Date();
    @Column(name="UpdatedBy")
    private String updatedBy;
    @Column(name="UpdateDate", columnDefinition = "DATETIME default CURRENT_TIMESTAMP")
    private Date updatedDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNamaJenis() {
        return namaJenis;
    }

    public void setNamaJenis(String namaJenis) {
        this.namaJenis = namaJenis;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }
}
