package com.restau.hcrestau.dto.jenis;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class JenisMenuDTO {

    @NotEmpty
    @NotNull
    @NotBlank
    private String namaJenis;

    public String getNamaJenis() {
        return namaJenis;
    }

    public void setNamaJenis(String namaJenis) {
        this.namaJenis = namaJenis;
    }
}
