package com.restau.hcrestau.service;

import com.restau.hcrestau.core.IService;
import com.restau.hcrestau.dto.SearchParamDTO;
import com.restau.hcrestau.dto.jenis.JenisPaginationDTO;
import com.restau.hcrestau.dto.menu.MenuPaginationDTO;
import com.restau.hcrestau.dto.transaksi.GetDataTransaksiDTO;
import com.restau.hcrestau.handler.ResponseHandler;
import com.restau.hcrestau.model.*;
import com.restau.hcrestau.repo.ListStrukRepo;
import com.restau.hcrestau.repo.ListTransaksiRepo;
import com.restau.hcrestau.repo.MenuRepo;
import com.restau.hcrestau.repo.UsersRepo;
import com.restau.hcrestau.util.TransformToDTO;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Service
public class ListTransaksiService implements IService<ListTransaksiModel> {

    @Autowired
    private ListStrukRepo listStrukRepo;

    @Autowired
    private MenuRepo menuRepo;

    @Autowired
    private UsersRepo usersRepo;

    @Autowired
    private ListTransaksiRepo listTransaksiRepo;

    @Autowired
    private ModelMapper modelMapper;

    Map<String,Object> mapResult = new HashMap<>();
    TransformToDTO transformToDTO = new TransformToDTO();
    private List<SearchParamDTO> listSearchParamDTO  = new ArrayList<>();

    @Override
    public ResponseEntity<Object> save(ListTransaksiModel listTransaksiModel,
                                           HttpServletRequest request){
        if(listTransaksiModel == null){
            return new ResponseHandler().generateResponse("Data Tidak Valid",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }

        Optional<ListStrukModel> listStrukModelOptional = listStrukRepo.findById(listTransaksiModel.getListStrukModel().getId());
        Optional<MenuModel> menuModelOptional = menuRepo.findById(listTransaksiModel.getMenuModel().getIdMenu());

        if(listStrukModelOptional.isEmpty() || menuModelOptional.isEmpty()){
            return new ResponseHandler().generateResponse("Struk/Menu/User Tidak Valid",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01002", request);//FAILED VALIDATION
        }

        if(listStrukModelOptional.get().getPaid()){
            return new ResponseHandler().generateResponse("Kustomer sudah selesai transaksi!",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01003", request);//FAILED VALIDATION
        }

        try{
            MenuModel menuModel = menuModelOptional.get();
            listTransaksiModel.setHargaMenu(menuModel.getHargaMenu());
            listTransaksiModel.setTotalHarga(listTransaksiModel.getHargaMenu() * listTransaksiModel.getJumlahMenu());

            listTransaksiRepo.save(listTransaksiModel);


            return new ResponseHandler().generateResponse("Data Berhasil Disimpan",
                    HttpStatus.OK,
                    null,
                    "FS01001", request);//SUCCESS

        }catch(Exception e){
            return new ResponseHandler().generateResponse("Data Gagal Disimpan",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01003", request);
        }

    }

    public ResponseEntity<Object> cooked(Long id, Long idUser,HttpServletRequest request){
        Optional<ListTransaksiModel> listTransaksiModelOptional = listTransaksiRepo.findById(id);
        if(listTransaksiModelOptional.isEmpty()){
            return new ResponseHandler().generateResponse("Data Id Transaksi Tidak Ditemukan",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }

        Optional<UsersModel> usersModelOptional = usersRepo.findById(idUser);
        if(usersModelOptional.isEmpty()){
            return new ResponseHandler().generateResponse("Data Id Kasir Tidak Ditemukan",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }

        try{
            ListTransaksiModel listTransaksi = listTransaksiModelOptional.get();

            if(listTransaksi.getCooked() == true){
                return new ResponseHandler().generateResponse("Sudah dimasak!",
                        HttpStatus.BAD_REQUEST,
                        null,
                        "FV01001", request);//FAILED VALIDATION
            }
            listTransaksi.setCooked(true);
            listTransaksi.setUsersModel(usersModelOptional.get());
            listTransaksiRepo.save(listTransaksi);

            //Update Total Bayar on ListStruk
            Optional<ListStrukModel> listStrukModelOptional = listStrukRepo.findById(listTransaksi.getListStrukModel().getId());
            ListStrukModel listStrukModel = listStrukModelOptional.get();
            listStrukModel.setPajak(listStrukModel.getPajak() + (listTransaksi.getTotalHarga() * 0.11));
            listStrukModel.setTotalBayar(listStrukModel.getTotalBayar() + listTransaksi.getTotalHarga());
            listStrukModel.setTotalBayarAkhir(listStrukModel.getTotalBayar() + listStrukModel.getPajak());
            listStrukModel.setUpdatedDate(new Date());
            listStrukRepo.save(listStrukModel);


            return new ResponseHandler().generateResponse("Data Berhasil Disimpan",
                    HttpStatus.OK,
                    null,
                    "FS01001", request);//SUCCESS

        }catch (Exception e){
            return new ResponseHandler().generateResponse("Data Gagal Disimpan",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }
    }

    @Override
    public ResponseEntity<Object> saveBatch(List<ListTransaksiModel> lt, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> edit(Long id, ListTransaksiModel listTransaksiModel, HttpServletRequest request) {
        return null;
    }

    //Digunakan jika pesanan di cancel
    @Override
    public ResponseEntity<Object> delete(Long id, HttpServletRequest request) {
        Optional<ListTransaksiModel> listTransaksiModelOptional = listTransaksiRepo.findById(id);
        if(listTransaksiModelOptional.isEmpty()){
            return new ResponseHandler().generateResponse("Data Id Tidak Ditemukan",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }

        try{
            ListTransaksiModel listTransaksi = listTransaksiModelOptional.get();

            //check apakah isCooked, kalau cooked maka tidak bisa di hapus karena makanan sudah dibuat
            if(listTransaksi.getCooked()){
                return new ResponseHandler().generateResponse("Makanan/Minuman sudah dibuat, tidak dapat dihapus!",
                        HttpStatus.BAD_REQUEST,
                        null,
                        "FV01001", request);//FAILED VALIDATION
            }

            listTransaksiRepo.delete(listTransaksi);

            return new ResponseHandler().generateResponse("Data Berhasil Dihapus",
                    HttpStatus.OK,
                    null,
                    "FS01001", request);//SUCCESS

        }catch(Exception e){
            return new ResponseHandler().generateResponse("Data Gagal Dihapus",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }


    }

    @Override
    public ResponseEntity<Object> findById(Long id, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> find(Pageable pageable, String columFirst, String valueFirst, HttpServletRequest request) {
        Page<ListTransaksiModel> pageTransaksi = listTransaksiRepo.findAllWithJoin(pageable);
        List<ListTransaksiModel> listTransaksi = pageTransaksi.getContent();

        if(listTransaksi.isEmpty()) {
            return new ResponseHandler().
                    generateResponse("DATA TIDAK DITEMUKAN",
                            HttpStatus.NOT_FOUND,
                            null,
                            "X-99-002",
                            request);
        }

        List<GetDataTransaksiDTO> getDataTransaksiDTOs = new ArrayList<>();

        for (ListTransaksiModel listTransaksiModel : listTransaksi) {
            GetDataTransaksiDTO getDataTransaksiDTO = modelMapper.map(listTransaksiModel, new TypeToken<GetDataTransaksiDTO>() {}.getType());
            getDataTransaksiDTO.setNamaMenu(listTransaksiModel.getMenuModel().getNamaMenu());
            getDataTransaksiDTO.setNamaKustomer(listTransaksiModel.getListStrukModel().getNamaKustomer());

            if(listTransaksiModel.getUsersModel() != null) {
                getDataTransaksiDTO.setNamaDepan(listTransaksiModel.getUsersModel().getNamaDepan());
                getDataTransaksiDTO.setNamaBelakang(listTransaksiModel.getUsersModel().getNamaBelakang());
            }

            getDataTransaksiDTOs.add(getDataTransaksiDTO);
        }

        List<GetDataTransaksiDTO>  ltMenuDTO =
                modelMapper.map(getDataTransaksiDTOs, new TypeToken<List<GetDataTransaksiDTO>>() {}.getType());
        mapResult = transformToDTO.transformObject(mapResult,
                ltMenuDTO,
                pageTransaksi,
                columFirst,
                valueFirst,
                listSearchParamDTO);

        return  new ResponseHandler().
                generateResponse("OK",
                        HttpStatus.OK,
                        mapResult,
                        null,
                        request);

    }

    private Page<ListTransaksiModel> getDataByValue(Pageable pageable, String columnFirst, String valueFirst) {
        if(valueFirst.equals("") || valueFirst==null) {
            return listTransaksiRepo.findAll(pageable);
        }

        if(columnFirst.equals("id")){
            return listTransaksiRepo.findByIdContainingIgnoreCase(pageable, Long.parseLong(valueFirst));
        }
        return listTransaksiRepo.findAll(pageable);
    }

    @Override
    public ResponseEntity<Object> getAll(HttpServletRequest request) {
        List<ListTransaksiModel> listTransaksiModels = listTransaksiRepo.findAll();
        List<GetDataTransaksiDTO> getDataTransaksiDTOs = new ArrayList<>();

        for (ListTransaksiModel listTransaksiModel : listTransaksiModels) {
            Optional<ListStrukModel> listStrukModels = listStrukRepo.findById(listTransaksiModel.getListStrukModel().getId());
            Optional<MenuModel> menuModel = menuRepo.findById(listTransaksiModel.getMenuModel().getIdMenu());

            GetDataTransaksiDTO getDataTransaksiDTO = modelMapper.map(listTransaksiModel, new TypeToken<GetDataTransaksiDTO>() {}.getType());
            getDataTransaksiDTO.setNamaMenu(menuModel.get().getNamaMenu());
            getDataTransaksiDTO.setNamaKustomer(listStrukModels.get().getNamaKustomer());

            if(listTransaksiModel.getUsersModel() != null) {
                getDataTransaksiDTO.setNamaDepan(listTransaksiModel.getUsersModel().getNamaDepan());
                getDataTransaksiDTO.setNamaBelakang(listTransaksiModel.getUsersModel().getNamaBelakang());
            }
            getDataTransaksiDTOs.add(getDataTransaksiDTO);
        }

        return new ResponseHandler().generateResponse("Data Ditemukan",
                HttpStatus.OK,
                getDataTransaksiDTOs,
                "FS01001", request);
    }

    public ResponseEntity<Object> getTransaksiById(Long id, HttpServletRequest request){
        Optional<ListTransaksiModel> listTransaksiModelOptional = listTransaksiRepo.findById(id);
        if(listTransaksiModelOptional.isEmpty()){
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan",
                    HttpStatus.NOT_FOUND,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }

        ListTransaksiModel listTransaksiModel = listTransaksiModelOptional.get();
        Optional<ListStrukModel> listStrukModels = listStrukRepo.findById(listTransaksiModel.getListStrukModel().getId());
        Optional<MenuModel> menuModel = menuRepo.findById(listTransaksiModel.getMenuModel().getIdMenu());

        GetDataTransaksiDTO getDataTransaksiDTO = modelMapper.map(listTransaksiModel, new TypeToken<GetDataTransaksiDTO>() {}.getType());
        getDataTransaksiDTO.setNamaMenu(menuModel.get().getNamaMenu());
        getDataTransaksiDTO.setNamaKustomer(listStrukModels.get().getNamaKustomer());


        return new ResponseHandler().generateResponse("Data Ditemukan",
                HttpStatus.OK,
                getDataTransaksiDTO,
                "FS01001", request);//SUCCESS
    }
}
