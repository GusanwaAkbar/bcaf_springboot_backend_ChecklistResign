package com.restau.hcrestau.repo;

import com.restau.hcrestau.model.JenisMenuModel;
import com.restau.hcrestau.model.MenuModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface JenisMenuRepo extends JpaRepository<JenisMenuModel, Long> {
    Optional<JenisMenuModel> findTop1ById(Long id);

    Optional<JenisMenuModel> findByNamaJenis(String namaJenis);

    Page<JenisMenuModel> findByNamaJenisContainingIgnoreCase(Pageable pageable, String namaJenis);
    Page<JenisMenuModel> findByIdContainingIgnoreCase(Pageable pageable, Long id);

}
