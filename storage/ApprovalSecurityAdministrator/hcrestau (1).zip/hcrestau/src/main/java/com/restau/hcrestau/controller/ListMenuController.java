package com.restau.hcrestau.controller;

import com.restau.hcrestau.dto.menu.ListMenuDTO;
import com.restau.hcrestau.model.ListMenuModel;
import com.restau.hcrestau.service.ListMenuService;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/list-menu")
public class ListMenuController {

    @Autowired
    private ListMenuService listMenuService;
    @Autowired
    private ModelMapper modelMapper;

    @PostMapping("/v1/create")
    public ResponseEntity<Object> save(@Valid @RequestBody ListMenuDTO listMenuDTO, HttpServletRequest request){
        ListMenuModel listMenu = modelMapper.map(listMenuDTO, new TypeToken<ListMenuModel>() {}.getType());

        return listMenuService.save(listMenu,request);
    }
    @PostMapping("/v1/create/sb")
    public ResponseEntity<Object> saveBatch(@Valid @RequestBody List<ListMenuModel> ltListMenuDTO, HttpServletRequest request){
        List<ListMenuModel>  ltListMenu =
                modelMapper.map(ltListMenuDTO, new TypeToken<List<ListMenuModel>>() {}.getType());

        return listMenuService.saveBatch(ltListMenu,request);
    }

    @PutMapping("/v1/edit/{id}")
    public ResponseEntity<Object> edit(@PathVariable(value = "id") Long id, @Valid @RequestBody ListMenuDTO listMenuDTO, HttpServletRequest request){
        ListMenuModel listMenu = modelMapper.map(listMenuDTO, new TypeToken<ListMenuModel>() {}.getType());

        return listMenuService.edit(id,listMenu,request);
    }

    @DeleteMapping("/v1/delete/{id}")
    public ResponseEntity<Object> delete(@PathVariable(value = "id") Long id, HttpServletRequest request) {
        return listMenuService.delete(id, request);
    }

    @GetMapping("/v1/get-all")
    public ResponseEntity<Object> getAll(HttpServletRequest request) {

        return listMenuService.getAll(request);
    }
}
