package com.restau.hcrestau.service;

import com.restau.hcrestau.configuration.CloudinaryConfig;
import com.restau.hcrestau.core.IService;
import com.restau.hcrestau.dto.SearchParamDTO;
import com.restau.hcrestau.dto.menu.MenuDTO;
import com.restau.hcrestau.dto.menu.MenuIdDTO;
import com.restau.hcrestau.dto.menu.MenuPaginationDTO;
import com.restau.hcrestau.handler.ResponseHandler;
import com.restau.hcrestau.model.JenisMenuModel;
import com.restau.hcrestau.model.MenuModel;
import com.restau.hcrestau.model.UsersModel;
import com.restau.hcrestau.repo.JenisMenuRepo;
import com.restau.hcrestau.repo.MenuRepo;
import com.restau.hcrestau.util.TransformToDTO;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.time.LocalDateTime;
import java.util.*;
import java.util.List;

@Service
public class MenuService implements IService<MenuModel> {

    @Autowired
    private MenuRepo menuRepo;

    @Autowired
    private JenisMenuRepo jenisMenuRepo;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    CloudinaryConfig cloudinaryConfig;

    private List<SearchParamDTO> listSearchParamDTO  = new ArrayList<>();

    Map<String,Object> mapResult = new HashMap<>();
    TransformToDTO transformToDTO = new TransformToDTO();


    @Override
    public ResponseEntity<Object> save(MenuModel menuModel, HttpServletRequest request) {

        if(menuModel==null)
        {
            return new ResponseHandler().generateResponse("Data Tidak Valid",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }
        var jenisMenu = jenisMenuRepo.findTop1ById(menuModel.getJenisMenuModel().getId());


        if(jenisMenu.isEmpty()){
            return new ResponseHandler().generateResponse("Jenis Menu tidak tersedia!",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01002", request);//FAILED VALIDATION
        }
        try{
            menuModel.setJenisMenuModel(jenisMenu.get());
            menuRepo.save(menuModel);
        }catch (Exception e)
        {
            return new ResponseHandler().generateResponse("Data Gagal Disimpan",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    null,
                    "FE01003", request);//FAILED ERROR
        }

        return new ResponseHandler().generateResponse("Berhasil Disimpan!",
                HttpStatus.CREATED,
                null,
                null, request);
    }


    public ResponseEntity<Object> saveMenu(MenuModel menuModel, MultipartFile file, HttpServletRequest request) {
        if(menuModel == null || file == null){
            return new ResponseHandler().generateResponse("Data Tidak Valid",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }
        var jenisMenu = jenisMenuRepo.findTop1ById(menuModel.getJenisMenuModel().getId());


        if(jenisMenu.isEmpty()){
            return new ResponseHandler().generateResponse("Jenis Menu tidak tersedia!",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01002", request);//FAILED VALIDATION
        }

        try{
            BufferedImage bi = ImageIO.read(file.getInputStream());
            if (bi == null) {
                return new ResponseEntity<>("Gambar tidak valid!", HttpStatus.BAD_REQUEST);
            }
            Map result = cloudinaryConfig.upload(file);

            System.out.println(result);

            String imageId = (String) result.get("public_id");
            String[] parts = imageId.split("/");
            String filename = parts[1];


            menuModel.setGambar((String) result.get("url"));
            menuModel.setIdGambar(filename);
            menuModel.setJenisMenuModel(jenisMenu.get());
            menuRepo.save(menuModel);
            return new ResponseHandler().generateResponse("Data Berhasil Disimpan",
                    HttpStatus.OK,
                    null,
                    "FS01001", request);//SUCCESS
        }catch(Exception e){
            return new ResponseHandler().generateResponse("Data Gagal Disimpan",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    null,
                    "FE01002", request);//FAILED ERROR
        }

    }

    @Override
    public ResponseEntity<Object> saveBatch(List<MenuModel> lt, HttpServletRequest request) {
        return null;
    }

    public ResponseEntity<Object> editById(Long id, MenuModel menuModel, MultipartFile file,HttpServletRequest request){
        Optional<MenuModel> optionalMenuModel = menuRepo.findById(id);
        if(optionalMenuModel.isEmpty())
        {
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01004", request);//FAILED VALIDATION
        }

        MenuModel oM= optionalMenuModel.get();
        String cloudinaryImgId = oM.getIdGambar();

        try{
            if (file != null) {
                //Upload the new image
                BufferedImage bi = ImageIO.read(file.getInputStream());
                if (bi != null) {
                    //Delete the cloudinary id first
                    cloudinaryConfig.delete(cloudinaryImgId);
                    Map result = cloudinaryConfig.upload(file);
                    String imageId = (String) result.get("public_id");
                    String[] parts = imageId.split("/");
                    String filename = parts[1];
                    oM.setGambar((String) result.get("url"));
                    oM.setIdGambar(filename);
                }
            }

            if (menuModel.getJenisMenuModel() != null) {
                var jenisMenu = jenisMenuRepo.findTop1ById(menuModel.getJenisMenuModel().getId());
                oM.setJenisMenuModel(jenisMenu.get());
            }
            if (menuModel.getNamaMenu() != null) {
                oM.setNamaMenu(menuModel.getNamaMenu());
            }
            if (menuModel.getHargaMenu() != null) {
                oM.setHargaMenu(menuModel.getHargaMenu());
            }

            menuRepo.save(oM);
            return new ResponseHandler().generateResponse("Data Berhasil Diupdate",
                    HttpStatus.OK,
                    null,
                    "FS01002", request);
        }catch(Exception e){
            return new ResponseHandler().generateResponse("Data Gagal Diupdate",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    null,
                    "FE01003", request);
        }
    }

    @Override
    public ResponseEntity<Object> edit(Long id, MenuModel menuModel, HttpServletRequest request) {
        return null;
    }

    public ResponseEntity<Object> editAvail(Long id, MenuModel menuModel, HttpServletRequest request){
        Optional<MenuModel> optionalMenuModel = menuRepo.findById(id);
        if(optionalMenuModel.isEmpty()) {
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan/Kosong",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01004", request);//FAILED VALIDATION
        }
        MenuModel oM= optionalMenuModel.get();

        oM.setAvailable(menuModel.getAvailable());
        oM.setUpdatedDate(new Date());
        menuRepo.save(oM);

        return new ResponseHandler().generateResponse("Berhasil Disimpan!",
                HttpStatus.OK,
                "Sukses update!",
                null, request);

    }

    @Override
    public ResponseEntity<Object> delete(Long id, HttpServletRequest request) {

        Optional<MenuModel> optionalMenuModel = menuRepo.findById(id);

        if(optionalMenuModel.isEmpty()) {
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan/Kosong",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01004", request);//FAILED VALIDATION
        }
        menuRepo.deleteById(id);
        return new ResponseHandler().generateResponse("Berhasil Dihapus!",
                HttpStatus.OK,
                "Sukses delete!",
                null, request);
    }

    @Override
    public ResponseEntity<Object> findById(Long id, HttpServletRequest request) {
        Optional<MenuModel> menuModelOptional = menuRepo.findById(id);
        if(!menuModelOptional.isPresent()){
            return new ResponseHandler().generateResponse("Data Struk Tidak ditemukan", HttpStatus.NOT_FOUND, null, "FV01002", request);
        }
        MenuModel menuModel = menuModelOptional.get();
        Optional<JenisMenuModel> jenisMenuModel = jenisMenuRepo.findTop1ById(menuModel.getJenisMenuModel().getId());

        MenuIdDTO menuIdDTO = modelMapper.map(menuModel,new TypeToken<MenuIdDTO>() {}.getType());
        menuIdDTO.setIdJenisMenu(jenisMenuModel.get().getId());
        menuIdDTO.setNamaJenis(jenisMenuModel.get().getNamaJenis());

        return new ResponseHandler().generateResponse("Data Ditemukan",
                HttpStatus.OK,
                menuIdDTO,
                null, request);
    }

    @Override
    public ResponseEntity<Object> find(Pageable pageable, String columFirst, String valueFirst, HttpServletRequest request) {
        return null;
    }

    public ResponseEntity<Object> findMenu(Pageable pageable, String columFirst, String valueFirst, Long id, HttpServletRequest request) {
        Page<MenuModel> pageMenu = null;
        List<MenuModel> listMenu = null;

        if(columFirst.equals("id")) {
            if(!valueFirst.equals("") && valueFirst!=null) {
                try {
                    Long.parseLong(valueFirst);
                }
                catch (Exception e)
                {
                    return new ResponseHandler().
                            generateResponse("DATA FILTER TIDAK SESUAI FORMAT HARUS ANGKA",
                                    HttpStatus.INTERNAL_SERVER_ERROR,
                                    null,//perubahan 21-12-2023
                                    "X-99-001",
                                    request);
                }
            }
        }

        pageMenu = getDataByValue(pageable,columFirst,valueFirst,id);
        listMenu = pageMenu.getContent();
        if(listMenu.isEmpty())
        {
            return new ResponseHandler().
                    generateResponse("DATA TIDAK DITEMUKAN",
                            HttpStatus.NOT_FOUND,
                            null,//perubahan 21-12-2023
                            "X-99-002",
                            request);
        }
        List<MenuPaginationDTO>  ltMenuDTO =
                modelMapper.map(listMenu, new TypeToken<List<MenuPaginationDTO>>() {}.getType());
        mapResult = transformToDTO.transformObject(mapResult,
                ltMenuDTO,
                pageMenu,
                columFirst,
                valueFirst,
                listSearchParamDTO);

        return  new ResponseHandler().
                generateResponse("OK",
                        HttpStatus.OK,
                        mapResult,
                        null,
                        request);
    }


    @Override
    public ResponseEntity<Object> getAll(HttpServletRequest request) {
        List<MenuModel> menuModels = menuRepo.findAll();

        if(menuModels.isEmpty())
        {
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan/Kosong",
                    HttpStatus.NOT_FOUND,
                    null,
                    "FV01005", request);//FAILED VALIDATION
        }

        return new ResponseHandler().generateResponse("Berhasil Diambil!",
                HttpStatus.OK,
                menuModels,
                null, request);
    }

    //get Value based on the jenis Menu id
    private Page<MenuModel> getDataByValue(Pageable pageable, String columnFirst, String valueFirst, Long id)
    {
        Specification<MenuModel> spec = Specification.where((root, query, cb) -> cb.equal(root.get("jenisMenuModel").get("id"), id));

        if(valueFirst.equals("") || valueFirst==null)
        {
            return menuRepo.findAll(spec, pageable);
        }

        if (columnFirst.equals("namaMenu")) {
            spec = spec.and((root, query, cb) -> cb.like(cb.lower(root.get("namaMenu")), "%" + valueFirst.toLowerCase() + "%"));
        } else if (columnFirst.equals("hargaMenu")){
            spec = spec.and((root, query, cb) -> cb.equal(root.get("hargaMenu"), Double.parseDouble(valueFirst)));
        }

        return menuRepo.findAll(spec, pageable);
    }


}
