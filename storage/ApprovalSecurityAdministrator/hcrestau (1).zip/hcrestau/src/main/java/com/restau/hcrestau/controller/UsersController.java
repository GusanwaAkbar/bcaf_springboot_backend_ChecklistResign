package com.restau.hcrestau.controller;

import com.restau.hcrestau.dto.users.UsersDTO;
import com.restau.hcrestau.dto.auth.LoginDTO;
import com.restau.hcrestau.dto.auth.RegisDTO;
import com.restau.hcrestau.dto.auth.TokenDTO;
import com.restau.hcrestau.model.AksesMenuModel;
import com.restau.hcrestau.model.UsersModel;
import com.restau.hcrestau.service.UsersService;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/users")

public class UsersController {

    @Autowired
    UsersService usersService;
    @Autowired
    private ModelMapper modelMapper;

    private Map<String,String> mapSorting = new HashMap<String,String>();
    public UsersController() {
        mapSorting();
    }

    private void mapSorting()
    {
        mapSorting.put("id","id");
        mapSorting.put("namaDepan","namaDepan");
        mapSorting.put("namaBelakang","namaBelakang");
        mapSorting.put("createdDate","createdDate");
    }

    //Registration User
    @PostMapping("/v1/regis")
    public ResponseEntity<Object> doRegis(@RequestBody @Valid RegisDTO regisDTO,
                                          HttpServletRequest request) {
        UsersModel user = modelMapper.map(regisDTO, new TypeToken<UsersModel>() {}.getType());
        AksesMenuModel aksesMenuModel = new AksesMenuModel();
        aksesMenuModel.setId(regisDTO.getAkses());
        user.setAksesMenuModel(aksesMenuModel);
        return usersService.checkRegis(user,request);
    }

    //Login User
    @PostMapping("/v1/login")
    public ResponseEntity<Object> login(@Valid @RequestBody LoginDTO loginDTO,
                                        HttpServletRequest request) {
        UsersModel user = modelMapper.map(loginDTO,new TypeToken<UsersModel>(){}.getType());
        return usersService.doLogin(user,request);
    }

    //Edit User
    @PutMapping("/v1/edit/{id}")
    public ResponseEntity<Object> edit(@PathVariable(value = "id") Long id,
                                       @RequestBody @Valid UsersDTO usersDTO ,
                                       HttpServletRequest request){
        UsersModel user = modelMapper.map(usersDTO,new TypeToken<UsersModel>() {}.getType());
        AksesMenuModel aksesMenuModel = new AksesMenuModel();
        aksesMenuModel.setId(usersDTO.getAkses());
        user.setAksesMenuModel(aksesMenuModel);
        return usersService.edit(id,user,request);
    }

    //Delete User
    @DeleteMapping("/v1/delete/{id}")
    public ResponseEntity<Object> delete(@PathVariable(value = "id") Long id,
                                         HttpServletRequest request) {
        return usersService.delete(id, request);
    }

    //Get All User
    @GetMapping("/v1/get-all")
    public ResponseEntity<Object> getAll(HttpServletRequest request) {

        return usersService.getAll(request);
    }

    //Get User by Id
    @GetMapping("/v1/get-user/{id}")
    public ResponseEntity<Object> getUserById(@PathVariable(value = "id") Long id,
                                              HttpServletRequest request) {
        return usersService.getUserById(id, request);
    }
    //Get User Pagination
    @GetMapping("/v1/get-user/{page}/{sort}/{sortBy}")
    public ResponseEntity<Object> find(@PathVariable(value = "page") Integer page,
                                       @PathVariable(value = "sort") String sort,
                                       @PathVariable(value = "sortBy") String sortBy,
                                       @RequestParam("filterBy") String filterBy,
                                       @RequestParam("value") String value,
                                       @RequestParam("size") String size,
                                       HttpServletRequest request) {
        Pageable pageable = null;
        page = page==null?0:page;
        sortBy = (sortBy==null || sortBy.equals(""))?"id":sortBy;
        sort   = (sort==null || sort.equals("") || sort.equals("asc"))?"asc":"desc";

        sortBy = mapSorting.get(sortBy);
        pageable = PageRequest.of(page,Integer.parseInt(size.equals("")?"10":size),
                sort.equals("desc")? Sort.by(sortBy).descending():Sort.by(sortBy));

        return usersService.find(pageable,filterBy,value,request);
    }


    //Input Token User
    @PostMapping("/token")
    public ResponseEntity<Object> inputToken(@Valid @RequestBody TokenDTO tokenDTO,
                                             HttpServletRequest request) {
        UsersModel usersModel = modelMapper.map(tokenDTO,new TypeToken<UsersModel>(){}.getType());
        return usersService.inputToken(usersModel,request);
    }


}
