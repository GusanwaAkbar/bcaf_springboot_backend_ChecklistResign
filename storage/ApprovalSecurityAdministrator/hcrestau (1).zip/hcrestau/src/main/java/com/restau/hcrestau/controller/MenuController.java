package com.restau.hcrestau.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.restau.hcrestau.dto.menu.MenuAvailabilityDTO;
import com.restau.hcrestau.dto.menu.MenuDTO;
import com.restau.hcrestau.model.JenisMenuModel;
import com.restau.hcrestau.model.MenuModel;
import com.restau.hcrestau.service.MenuService;
import org.apache.coyote.Response;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/menu")
public class MenuController {


    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private MenuService menuService;

    private ObjectMapper objectMapper;

    private Map<String,String> mapSorting = new HashMap<String,String>();
    public MenuController() {
        mapSorting();
    }

    private void mapSorting()
    {
        mapSorting.put("id","idMenu");
        mapSorting.put("namaMenu","namaMenu");
        mapSorting.put("hargaMenu","hargaMenu");
        mapSorting.put("gambar","gambar");
        mapSorting.put("available","available");
    }


    @PostMapping("/v1/create")
    public ResponseEntity<Object> save(@RequestParam(value = "namaMenu") String namaMenu,
                                       @RequestParam(value="jenisMenu") Long jenisMenu,
                                       @RequestParam(value = "hargaMenu") Double hargaMenu,
                                       @RequestParam(value = "file") MultipartFile file, HttpServletRequest request) {

        MenuDTO menuDTO = new MenuDTO(namaMenu, hargaMenu, jenisMenu);
        MenuModel menu = modelMapper.map(menuDTO, MenuModel.class);

        JenisMenuModel jenisMenuModel = new JenisMenuModel();
        jenisMenuModel.setId(menuDTO.getJenisMenu());
        menu.setJenisMenuModel(jenisMenuModel);

        return menuService.saveMenu(menu, file, request);
    }



    @PutMapping("/v1/edit/{id}")
    public ResponseEntity<Object> edit(@PathVariable(value = "id") Long id,
                                       @RequestParam(value = "namaMenu",required = false) String namaMenu,
                                       @RequestParam(value = "jenisMenu",required = false) Long jenisMenu,
                                       @RequestParam(value = "hargaMenu",required = false) Double hargaMenu,
                                       @RequestParam(value = "file",required = false) MultipartFile file,
                                       HttpServletRequest request){

        MenuDTO menuDTO = new MenuDTO(namaMenu, hargaMenu, jenisMenu);
        MenuModel menu = modelMapper.map(menuDTO, MenuModel.class);

        if (jenisMenu != null) {
            JenisMenuModel jenisMenuModel = new JenisMenuModel();
            jenisMenuModel.setId(menuDTO.getJenisMenu());
            menu.setJenisMenuModel(jenisMenuModel);
        }

        return menuService.editById(id,menu,file,request);
    }

    @PutMapping("/v1/edit-avail/{id}")
    public ResponseEntity<Object> editAvail(@PathVariable(value = "id") Long id,
                                            @RequestBody MenuAvailabilityDTO menuAvailabilityDTO,
                                            HttpServletRequest request){
        MenuModel menu = modelMapper.map(menuAvailabilityDTO, MenuModel.class);
        return menuService.editAvail(id,menu,request);
    }

    @DeleteMapping("/v1/delete/{id}")
    public ResponseEntity<Object> delete(@PathVariable(value = "id") Long id,
                                         HttpServletRequest request) {
        return menuService.delete(id, request);
    }

    @GetMapping("/v1/get-all")
    public ResponseEntity<Object> getAll(HttpServletRequest request) {
        return menuService.getAll(request);
    }

    @GetMapping("/v1/get-menu/{id}")
    public ResponseEntity<Object> getById(@PathVariable(value = "id") Long id,
                                          HttpServletRequest request) {
        return menuService.findById(id, request);
    }

    @GetMapping("/v1/get-menu/{page}/{sort}/{sortBy}/{id}")
    public ResponseEntity<Object> find(@PathVariable(value = "page") Integer page,
                                       @PathVariable(value = "sort") String sort,
                                       @PathVariable(value = "sortBy") String sortBy,
                                       @PathVariable(value = "id") Long id,
                                       @RequestParam("filterBy") String filterBy,
                                       @RequestParam("value") String value,
                                       @RequestParam("size") String size,
                                       HttpServletRequest request) {
        Pageable pageable = null;
        page = page==null?0:page;
        sortBy = (sortBy==null || sortBy.equals(""))?"id":sortBy;
        sort   = (sort==null || sort.equals("") || sort.equals("asc"))?"asc":"desc";

        sortBy = mapSorting.get(sortBy);// id = idGroupMenu, nama = namaGroupMenu dst....
        pageable = PageRequest.of(page,Integer.parseInt(size.equals("")?"10":size),
                sort.equals("desc")? Sort.by(sortBy).descending():Sort.by(sortBy));
        return menuService.findMenu(pageable,filterBy,value,id,request);
    }
}
