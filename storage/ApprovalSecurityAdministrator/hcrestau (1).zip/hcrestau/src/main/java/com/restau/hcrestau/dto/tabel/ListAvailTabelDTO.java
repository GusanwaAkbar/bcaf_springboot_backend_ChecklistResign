package com.restau.hcrestau.dto.tabel;

public class ListAvailTabelDTO {
    private Boolean isAvail;

    public Boolean getAvail() {
        return isAvail;
    }

    public void setAvail(Boolean avail) {
        isAvail = avail;
    }
}
