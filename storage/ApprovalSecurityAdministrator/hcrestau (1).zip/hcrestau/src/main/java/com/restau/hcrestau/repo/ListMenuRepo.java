package com.restau.hcrestau.repo;

import com.restau.hcrestau.model.ListMenuModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ListMenuRepo extends JpaRepository<ListMenuModel,Long> {

    Optional<ListMenuModel> findByNamaMenu(String namaMenu);

}
