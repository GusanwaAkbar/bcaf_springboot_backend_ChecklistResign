package com.restau.hcrestau.dto.menu;

public class MenuIdDTO {

    private Long idMenu;
    private String namaMenu;
    private Double hargaMenu;
    private String gambar;

    //Diambil dari Jenis Menu
    private Long idJenisMenu;
    private String namaJenis;


    public MenuIdDTO() {
        // no-arg constructor
    }
    public Long getIdMenu() {
        return idMenu;
    }

    public void setIdMenu(Long idMenu) {
        this.idMenu = idMenu;
    }

    public String getNamaMenu() {
        return namaMenu;
    }

    public void setNamaMenu(String namaMenu) {
        this.namaMenu = namaMenu;
    }

    public Double getHargaMenu() {
        return hargaMenu;
    }

    public void setHargaMenu(Double hargaMenu) {
        this.hargaMenu = hargaMenu;
    }

//    public Long getJenisMenu() {
//        return jenisMenu;
//    }
//
//    public void setJenisMenu(Long jenisMenu) {
//        this.jenisMenu = jenisMenu;
//    }


    public Long getIdJenisMenu() {
        return idJenisMenu;
    }

    public void setIdJenisMenu(Long idJenisMenu) {
        this.idJenisMenu = idJenisMenu;
    }

    public String getNamaJenis() {
        return namaJenis;
    }

    public void setNamaJenis(String namaJenis) {
        this.namaJenis = namaJenis;
    }

    public String getGambar() {
        return gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }
}
