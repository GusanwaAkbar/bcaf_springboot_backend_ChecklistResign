package com.restau.hcrestau.dto.transaksi;

public class GetDataTransaksiDTO {
    //Diambil langsung dari Transaksi
    private long id;
    private Double hargaMenu;
    private Boolean isCooked;
    private Integer jumlahMenu;
    private Double totalHarga;

    //Diambil dari Struk
    private String namaKustomer;

    //Diambil dari Menu
    private String namaMenu;

    //Diambil dari User
    private String namaDepan;
    private String namaBelakang;



    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNamaKustomer() {
        return namaKustomer;
    }

    public void setNamaKustomer(String namaKustomer) {
        this.namaKustomer = namaKustomer;
    }

    public String getNamaMenu() {
        return namaMenu;
    }

    public void setNamaMenu(String namaMenu) {
        this.namaMenu = namaMenu;
    }

    public Double getHargaMenu() {
        return hargaMenu;
    }

    public void setHargaMenu(Double hargaMenu) {
        this.hargaMenu = hargaMenu;
    }

    public Boolean getCooked() {
        return isCooked;
    }

    public void setCooked(Boolean cooked) {
        isCooked = cooked;
    }

    public Integer getJumlahMenu() {
        return jumlahMenu;
    }

    public void setJumlahMenu(Integer jumlahMenu) {
        this.jumlahMenu = jumlahMenu;
    }

    public Double getTotalHarga() {
        return totalHarga;
    }

    public void setTotalHarga(Double totalHarga) {
        this.totalHarga = totalHarga;
    }

    public String getNamaDepan() {
        return namaDepan;
    }

    public void setNamaDepan(String namaDepan) {
        this.namaDepan = namaDepan;
    }

    public String getNamaBelakang() {
        return namaBelakang;
    }

    public void setNamaBelakang(String namaBelakang) {
        this.namaBelakang = namaBelakang;
    }
}
