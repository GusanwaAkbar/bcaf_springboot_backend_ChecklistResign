package com.restau.hcrestau.dto.tabel;

import com.restau.hcrestau.model.ListAvailTabelModel;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class ListTabelIsDoneDTO {

    @NotNull(message = "No Tabel Tidak Boleh Null")
    @NotBlank(message = "No Tabel Tidak Boleh Mengandung Spasi")
    @NotEmpty(message = "No Tabel Tidak Boleh Kosong")
    private ListAvailTabelModel listAvailTabelModel;

    @NotNull(message = "Status Tabel Tidak Boleh Null")
    @NotBlank(message = "Status Tabel Tidak Boleh Mengandung Spasi")
    @NotEmpty(message = "Status TabelTidak Boleh Kosong")
    private Boolean isDone;

    public ListAvailTabelModel getListAvailTabelModel() {
        return listAvailTabelModel;
    }

    public void setListAvailTabelModel(ListAvailTabelModel listAvailTabelModel) {
        this.listAvailTabelModel = listAvailTabelModel;
    }

    public Boolean getDone() {
        return isDone;
    }

    public void setDone(Boolean done) {
        isDone = done;
    }
}

