package com.restau.hcrestau.core;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface IService <T>{

    public ResponseEntity<Object> save(T t, HttpServletRequest request); //untuk menyimpan sebuah objek
    public ResponseEntity<Object> saveBatch(List<T> lt, HttpServletRequest request); //untuk menyimpan list objek
    public ResponseEntity<Object> edit(Long id, T t, HttpServletRequest request);
    public ResponseEntity<Object> delete(Long id, HttpServletRequest request);
    public ResponseEntity<Object> findById(Long id, HttpServletRequest request);
    public ResponseEntity<Object> find(Pageable pageable, String columFirst, String valueFirst, HttpServletRequest request); //berdasarkan paginasi
    public ResponseEntity<Object> getAll(HttpServletRequest request);
}
