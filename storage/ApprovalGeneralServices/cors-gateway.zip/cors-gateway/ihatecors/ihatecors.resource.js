const fetch = require("node-fetch-commonjs");
const axios = require("axios");
const express = require("express");
const multer = require('multer');
const upload = multer();

const IHateCORSResource = express.Router();

IHateCORSResource.use("", upload.single('file'), async (req, res) => {
	try {
		let headers = {
			"Content-Type": req.headers["content-type"],
			Authorization: req.headers["authorization"],
		};

		let form = new FormData();

		if (req.file) {
			const file_blob = new Blob([req.file.buffer], { type: req.file.mimetype })
			form.append('file', file_blob, req.file.originalname);
		}

		let body = req.file ? form : JSON.stringify(req.body);
		
		let response = await axios({
			method: req.method.toLocaleLowerCase(),
			url: `http://localhost:3030${req.path}`,
			data: body,
			headers,
			params: { ...req.query },
			responseType: "application/json",
		});

		// const response = await axios.post(, {headers})
		return res.status(200).json(JSON.parse(response.data));
	} catch (error) {
		function isJsonString(str) {
			try {
					JSON.parse(str);
			} catch (e) {
					return false;
			}
			return true;
		}

		const isJsonStr = isJsonString(error?.response?.data);

		if (isJsonStr) {
			return res.status(400).json(JSON.parse(error?.response?.data));
		} else {
			return res.status(400).json({ error: error?.response?.data });
		}
	}
});

module.exports = {
	IHateCORSResource,
};
