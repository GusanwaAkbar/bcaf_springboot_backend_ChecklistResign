//package com.restau.hcrestau.dto.transaksi;
//
//import com.restau.hcrestau.model.ListStrukModel;
//import com.restau.hcrestau.model.MenuModel;
//import com.restau.hcrestau.model.UsersModel;
//
//import javax.validation.constraints.NotBlank;
//import javax.validation.constraints.NotEmpty;
//import javax.validation.constraints.NotNull;
//
//public class InputListTransaksiDTO {
//
//
//    @NotNull(message = "Struk Tidak Boleh Null")
//    private ListStrukModel listStrukModel;
//
//    @NotNull(message = "Menu Tidak Boleh Null")
//    private MenuModel menuModel;
//
//    @NotNull(message = "Approver Tidak Boleh Null")
//    private UsersModel userModel;
//
//    @NotNull(message = "Jumlah Menu Tidak Boleh Null")
//    private Integer jumlahMenu;
//
//    public ListStrukModel getListStrukModel() {
//        return listStrukModel;
//    }
//
//    public void setListStrukModel(ListStrukModel listStrukModel) {
//        this.listStrukModel = listStrukModel;
//    }
//
//    public MenuModel getMenuModel() {
//        return menuModel;
//    }
//
//    public void setMenuModel(MenuModel menuModel) {
//        this.menuModel = menuModel;
//    }
//
//    public UsersModel getUserModel() {
//        return userModel;
//    }
//
//    public void setUserModel(UsersModel userModel) {
//        this.userModel = userModel;
//    }
//
//    public Integer getJumlahMenu() {
//        return jumlahMenu;
//    }
//
//    public void setJumlahMenu(Integer jumlahMenu) {
//        this.jumlahMenu = jumlahMenu;
//    }
//}
