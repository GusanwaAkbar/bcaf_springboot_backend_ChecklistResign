package com.restau.hcrestau.model;


import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.restau.hcrestau.constant.ScriptDBSQLServer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import org.apache.catalina.User;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "AksesMenu")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
//@NoArgsConstructor
//@AllArgsConstructor
//@Builder
public class AksesMenuModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdAkses")
    private Long id;

    @Column(name="NamaAkses",unique = true)
    private String namaAkses;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "MapAksesToListMenu",joinColumns = @JoinColumn(name = "IdAkses",foreignKey = @ForeignKey(name = "FK_AKSES_TO_LISTMENU",foreignKeyDefinition = ScriptDBSQLServer.FK_AKSES)),
            inverseJoinColumns = @JoinColumn(name = "IdListMenu",foreignKey = @ForeignKey(name = "FK_LISTMENU_TO_AKSES",foreignKeyDefinition = ScriptDBSQLServer.FK_LISTMENU))
    )
    private List<ListMenuModel> ltMenuModel;

    //    Audit Trails
    @Column(name="CreatedBy",updatable = false)
    private String createdBy;
    @Column(name="CreatedDate", columnDefinition = "DATETIME default CURRENT_TIMESTAMP",updatable = false)
    private Date createdDate = new Date();
    @Column(name="UpdatedBy")
    private String updatedBy;
    @Column(name="UpdateDate", columnDefinition = "DATETIME default CURRENT_TIMESTAMP")
    private Date updatedDate;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNamaAkses() {
        return namaAkses;
    }

    public void setNamaAkses(String namaAkses) {
        this.namaAkses = namaAkses;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public List<ListMenuModel> getLtMenuModel() {
        return ltMenuModel;
    }

    public void setLtMenuModel(List<ListMenuModel> ltMenuModel) {
        this.ltMenuModel = ltMenuModel;
    }
}
