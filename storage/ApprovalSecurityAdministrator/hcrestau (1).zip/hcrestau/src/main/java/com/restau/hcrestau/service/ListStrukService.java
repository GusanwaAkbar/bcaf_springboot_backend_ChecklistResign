package com.restau.hcrestau.service;

import com.restau.hcrestau.core.IService;
import com.restau.hcrestau.dto.SearchParamDTO;
import com.restau.hcrestau.dto.struk.GetDataStrukDTO;
import com.restau.hcrestau.dto.transaksi.GetDataTransaksiDTO;
import com.restau.hcrestau.handler.ResponseHandler;
import com.restau.hcrestau.model.*;
import com.restau.hcrestau.repo.ListAvailTabelRepo;
import com.restau.hcrestau.repo.ListStrukRepo;
import com.restau.hcrestau.repo.ListTransaksiRepo;
import com.restau.hcrestau.repo.MenuRepo;
import com.restau.hcrestau.util.TransformToDTO;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.stream.Stream;

@Service
public class ListStrukService implements IService<ListStrukModel>{

    @Autowired
    private ListAvailTabelRepo listAvailTabelRepo;

    @Autowired
    private ListStrukRepo listStrukRepo;

    @Autowired
    private ListTransaksiRepo listTransaksiRepo;

    @Autowired
    private MenuRepo menuRepo;

    @Autowired
    private ModelMapper modelMapper;
    private List<SearchParamDTO> listSearchParamDTO  = new ArrayList<>();


    Map<String,Object> mapResult = new HashMap<>();
    TransformToDTO transformToDTO = new TransformToDTO();


    @Override
    public ResponseEntity<Object> save(ListStrukModel listStrukModel, HttpServletRequest request) {
        if(listStrukModel==null)
        {
            return new ResponseHandler().generateResponse("Data Tidak Valid",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }


        Optional<ListAvailTabelModel> listAvailTabelModelOptional = listAvailTabelRepo.findById(listStrukModel.getListAvailTabelModel().getId());

        if(listAvailTabelModelOptional.isEmpty())
        {
            return new ResponseHandler().generateResponse("Nomor Tabel Tidak Valid",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }

        //Cek apakah meja sedang available atau tidak
        Optional<ListAvailTabelModel> checkIdTabelAndAvail = listAvailTabelRepo.findByIdAndIsAvail(listStrukModel.getListAvailTabelModel().getId(), true);
        if(checkIdTabelAndAvail.isEmpty()){
            return new ResponseHandler().generateResponse("Nomor Tabel Sudah Terisi",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }

        try{
            //Update listAvailTabel, set value Available to False on Id
            ListAvailTabelModel listAvailTabelModel = listAvailTabelModelOptional.get();
            listAvailTabelModel.setAvail(false);
            listAvailTabelRepo.save(listAvailTabelModel);

            //Save ListStruk
            listStrukRepo.save(listStrukModel);

            return new ResponseHandler().generateResponse("Data Berhasil Disimpan",
                    HttpStatus.OK,
                    null,
                    "FS01001", request);//SUCCESS

        }catch(Exception e){
            return new ResponseHandler().generateResponse("Data Gagal Disimpan",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    null,
                    "FE01002", request);//FAILED ERROR
        }
    }

    public ResponseEntity<Object> editPaid(Long id, HttpServletRequest request){

        Optional<ListStrukModel> listStrukModelOptional = listStrukRepo.findById(id);
        if(listStrukModelOptional.isEmpty()){
            return new ResponseHandler().generateResponse("Data Id Tidak Ditemukan",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }


        try{
            ListStrukModel listStruk = listStrukModelOptional.get();
            Optional<ListAvailTabelModel> listAvailTabelModelOptional = listAvailTabelRepo.findById(listStruk.getListAvailTabelModel().getId());
            if(listAvailTabelModelOptional.isEmpty()){
                return new ResponseHandler().generateResponse("Data Tabel Tidak Ditemukan",
                        HttpStatus.BAD_REQUEST,
                        null,
                        "FV01001", request);//FAILED VALIDATION
            }

            listStruk.setPaid(true);
            listStruk.setTanggalBayar(new Date());


            ListAvailTabelModel listAvailTabelModel = listAvailTabelModelOptional.get();
            listAvailTabelModel.setAvail(true);
            listAvailTabelModel.setUpdatedDate(new Date());

            listStrukRepo.save(listStruk);
            listAvailTabelRepo.save(listAvailTabelModel);

            return new ResponseHandler().generateResponse("Data Berhasil Disimpan",
                    HttpStatus.OK,
                    null,
                    "FS01001", request);//SUCCESS

        }catch(Exception e){
            return new ResponseHandler().generateResponse("Data Gagal Disimpan",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    null,
                    "FE01002", request);//FAILED ERROR
        }
    }

    @Override
    public ResponseEntity<Object> saveBatch(List<ListStrukModel> lt, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> edit(Long id, ListStrukModel listStrukModel, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> delete(Long id, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> findById(Long id, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> find(Pageable pageable, String columFirst, String valueFirst, HttpServletRequest request) {
        Page<ListStrukModel> pageStruk = null;
        List<ListStrukModel> listStruk = null;

        if(columFirst.equals("id")) {
            if(!valueFirst.equals("") && valueFirst!=null) {
                try {
                    Long.parseLong(valueFirst);
                }
                catch (Exception e)
                {
                    return new ResponseHandler().
                            generateResponse("DATA FILTER TIDAK SESUAI FORMAT HARUS ANGKA",
                                    HttpStatus.INTERNAL_SERVER_ERROR,
                                    null,//perubahan 21-12-2023
                                    "X-99-001",
                                    request);
                }
            }
        }

        pageStruk = getDataByValue(pageable, columFirst, valueFirst);
        listStruk = pageStruk.getContent();

        if(listStruk.isEmpty()) {
            return new ResponseHandler().
                    generateResponse("DATA TIDAK DITEMUKAN",
                            HttpStatus.NOT_FOUND,
                            null,
                            "X-99-002",
                            request);
        }

        List<Map<String, Object>> listStrukData = new ArrayList<>();

        for (ListStrukModel listStrukModel : listStruk) {
            Map<String, Object> map = new HashMap<>();
            map.put("id", listStrukModel.getId());
            map.put("namaKustomer", listStrukModel.getNamaKustomer());
            map.put("totalBayar", listStrukModel.getTotalBayar());
            map.put("pajak", listStrukModel.getPajak());
            map.put("totalBayarAkhir", listStrukModel.getTotalBayarAkhir());
            map.put("noTabel", listStrukModel.getListAvailTabelModel().getId());
            map.put("paid",listStrukModel.getPaid());

            List<ListTransaksiModel> listTransaksiModels = listTransaksiRepo.findByIdStruk(listStrukModel.getId());
            List<Map<String, Object>> transaksiList = new ArrayList<>();
            for(ListTransaksiModel listTransaksiModel : listTransaksiModels){
                Map<String,Object> mapTransaksi = new HashMap<>();
                mapTransaksi.put("idTransaksi",listTransaksiModel.getId());
                mapTransaksi.put("namaMenu",listTransaksiModel.getMenuModel().getNamaMenu());
                mapTransaksi.put("hargaMenu",listTransaksiModel.getHargaMenu());
                mapTransaksi.put("jumlahMenu",listTransaksiModel.getJumlahMenu());
                mapTransaksi.put("totalHarga",listTransaksiModel.getTotalHarga());
                mapTransaksi.put("cooked",listTransaksiModel.getCooked());
                transaksiList.add(mapTransaksi);
            }
            map.put("transaksi", transaksiList);

            listStrukData.add(map);
        }

        mapResult = transformToDTO.transformObject(mapResult,
                listStrukData,
                pageStruk,
                columFirst,
                valueFirst,
                listSearchParamDTO);

        return  new ResponseHandler().
                generateResponse("OK",
                        HttpStatus.OK,
                        mapResult,
                        null,
                        request);
    }

    @Override
    public ResponseEntity<Object> getAll(HttpServletRequest request) {
        List<ListStrukModel> listStrukModel = listStrukRepo.findAll();
        if(listStrukModel.isEmpty()){
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }

        return new ResponseHandler().generateResponse("Data Ditemukan",
                HttpStatus.OK,
                listStrukModel,
                "FS01001", request);//SUCCESS
    }

    public ResponseEntity<Object> getTransaksiByStrukId(Long id, HttpServletRequest request) {
        Optional<ListStrukModel> listStrukModelOptional = listStrukRepo.findById(id);
        if (!listStrukModelOptional.isPresent()) {
            return new ResponseHandler().generateResponse("Data Struk Tidak ditemukan", HttpStatus.NOT_FOUND, null, "FV01002", request);
        }
        ListStrukModel listStrukModel = listStrukModelOptional.get();


        List<ListTransaksiModel> listTransaksiModels = listTransaksiRepo.findByIdStruk(id);


        if (listTransaksiModels.isEmpty()) {
            return new ResponseHandler().generateResponse("Data Transaksi Tidak ditemukan", HttpStatus.NOT_FOUND, null, "FV01002", request);
        }

        Optional<ListAvailTabelModel> listAvailTabelModelOptional = listAvailTabelRepo.findById(listStrukModel.getListAvailTabelModel().getId());

        Map<String, Object> map = new HashMap<>();
        map.put("id",listStrukModel.getId());
        map.put("namaKustomer",listStrukModel.getNamaKustomer());
        map.put("totalBayar",listStrukModel.getTotalBayar());
        map.put("pajak",listStrukModel.getPajak());
        map.put("totalBayarAkhir",listStrukModel.getTotalBayarAkhir());
        map.put("noTabel",listStrukModel.getListAvailTabelModel().getId());
        List<Map<String, Object>> transaksiList = new ArrayList<>();

        for(int i=0;i<listTransaksiModels.size();i++){
            Map<String,Object> mapTransaksi = new HashMap<>();

            mapTransaksi.put("idTransaksi",listTransaksiModels.get(i).getId());
            mapTransaksi.put("namaMenu",listTransaksiModels.get(i).getMenuModel().getNamaMenu());
            mapTransaksi.put("hargaMenu",listTransaksiModels.get(i).getHargaMenu());
            mapTransaksi.put("jumlahMenu",listTransaksiModels.get(i).getJumlahMenu());
            mapTransaksi.put("totalHarga",listTransaksiModels.get(i).getTotalHarga());

            transaksiList.add(mapTransaksi);
        }

        map.put("transaksi", transaksiList);

        return new ResponseHandler().generateResponse("Data Ditemukan",
                HttpStatus.OK,
                map,
                "FS01001", request);//SUCCESS
    }

    private Page<ListStrukModel> getDataByValue(Pageable pageable, String columnFirst, String valueFirst) {
        if(valueFirst.equals("") || valueFirst == null){
            return listStrukRepo.findAll(pageable);
        }

        if(columnFirst.equals("id")){
            return listStrukRepo.findByIdContainingIgnoreCase(pageable, Long.parseLong(valueFirst));
        }else if(columnFirst.equals("namaKustomer")){
            return listStrukRepo.findByNamaKustomerContainingIgnoreCase(pageable, valueFirst);
        }
        return listStrukRepo.findAll(pageable);
    }
}
