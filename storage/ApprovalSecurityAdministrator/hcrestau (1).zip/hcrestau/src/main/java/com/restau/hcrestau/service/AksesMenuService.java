package com.restau.hcrestau.service;

import com.restau.hcrestau.core.IService;
import com.restau.hcrestau.dto.AksesMenuDTO;
import com.restau.hcrestau.handler.ResponseHandler;
import com.restau.hcrestau.model.AksesMenuModel;
import com.restau.hcrestau.model.JenisMenuModel;
import com.restau.hcrestau.repo.AksesMenuRepo;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class AksesMenuService implements IService<AksesMenuModel> {

    @Autowired
    private AksesMenuRepo aksesMenuRepo;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ResponseEntity<Object> save(AksesMenuModel aksesMenuModel, HttpServletRequest request) {

        if(aksesMenuModel==null)
        {
            return new ResponseHandler().generateResponse("Data Tidak Valid",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }


        Optional<AksesMenuModel> existingAksesMenuModel = aksesMenuRepo.findByNamaAkses(aksesMenuModel.getNamaAkses());
        if(existingAksesMenuModel.isPresent()) {
            return new ResponseHandler().generateResponse("Tidak Boleh Memasukkan Data yang sama!",
                    HttpStatus.CONFLICT,
                    null,
                    "FE01003", request);//FAILED ERROR
        }

        try{
            aksesMenuRepo.save(aksesMenuModel);
        }catch (Exception e)
        {
            return new ResponseHandler().generateResponse("Menu belum tersedia!",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    null,
                    "FE01002", request);//FAILED ERROR
        }

        return new ResponseHandler().generateResponse("Berhasil Disimpan!",
                HttpStatus.CREATED,
                null,
                null, request);
    }

    @Override
    public ResponseEntity<Object> saveBatch(List<AksesMenuModel> lt, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> edit(Long id, AksesMenuModel aksesMenuModel, HttpServletRequest request) {

        Optional<AksesMenuModel> optionalAksesMenuModel= aksesMenuRepo.findById(id);

        if(optionalAksesMenuModel.isEmpty())
        {
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan/Kosong",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01021", request);//FAILED VALIDATION
        }
        AksesMenuModel oAM = optionalAksesMenuModel.get();
        if (aksesMenuModel.getLtMenuModel() != null){
            oAM.setLtMenuModel(aksesMenuModel.getLtMenuModel());
        }
        if (aksesMenuModel.getNamaAkses() != null){
            oAM.setNamaAkses(aksesMenuModel.getNamaAkses());
        }
        oAM.setUpdatedDate(new Date());

        aksesMenuRepo.save(oAM);
        System.out.println(oAM);

//        AksesMenuDTO aksesMenuDTO =
//                modelMapper.map(oAM, new TypeToken<AksesMenuDTO>() {}.getType());

        return new ResponseHandler().generateResponse("Berhasil Disimpan!",
                HttpStatus.OK,
                "Sukses update!",
                null, request);
    }

    @Override
    public ResponseEntity<Object> delete(Long id, HttpServletRequest request) {
        Optional<AksesMenuModel> optionalAksesMenuModel= aksesMenuRepo.findById(id);

        if(optionalAksesMenuModel.isEmpty())
        {
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan/Kosong",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01021", request);//FAILED VALIDATION
        }
        AksesMenuModel oAM = optionalAksesMenuModel.get();
        aksesMenuRepo.delete(oAM);

        return new ResponseHandler().generateResponse("Berhasil Dihapus!",
                HttpStatus.OK,
                "Sukses delete!",
                null, request);
    }

    @Override
    public ResponseEntity<Object> findById(Long id, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> find(Pageable pageable, String columFirst, String valueFirst, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> getAll(HttpServletRequest request) {
        List<AksesMenuModel> aksesMenuModels = aksesMenuRepo.findAll();
        List<AksesMenuDTO> aksesMenuDTOS =
                modelMapper.map(aksesMenuModels, new TypeToken<List<AksesMenuDTO>>() {}.getType());

        if(aksesMenuDTOS.isEmpty())
        {
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan/Kosong",
                    HttpStatus.NOT_FOUND,
                    null,
                    "FV01021", request);//FAILED VALIDATION
        }

        return new ResponseHandler().generateResponse("Berhasil Diambil!",
                HttpStatus.OK,
                aksesMenuDTOS,
                null, request);
    }

}
