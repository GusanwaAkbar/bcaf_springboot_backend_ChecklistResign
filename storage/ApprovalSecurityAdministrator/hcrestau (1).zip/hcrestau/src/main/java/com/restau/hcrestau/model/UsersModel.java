package com.restau.hcrestau.model;

import com.restau.hcrestau.constant.ScriptDBSQLServer;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Table(name = "Users")
public class UsersModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdUser")
    private Long id;

    @Column(name="EmailUser",unique = true)
    private String email;
    @Column(name="PassUser")
    private String pass;
    @Column(name="NamaDepan")
    private String namaDepan;
    @Column(name="NamaBelakang")
    private String namaBelakang;

    @Column(name = "Token")
    private String token;

    @Column(name = "IsRegistered")
    private Boolean isRegistered = false;

//    Audit Trails
    @Column(name="CreatedBy",updatable = false)
    private String createdBy;
    @Column(name="CreatedDate", columnDefinition = "DATETIME default CURRENT_TIMESTAMP",updatable = false)
    private Date createdDate  = new Date();;
    @Column(name="UpdatedBy")
    private String updatedBy;
    @Column(name="UpdateDate", columnDefinition = "DATETIME default CURRENT_TIMESTAMP")
    private Date updatedDate;

    @ManyToOne
    @JoinColumn(name="IdAkses",foreignKey = @ForeignKey(name = "FK_USERS_TO_AKSESMENU",foreignKeyDefinition = ScriptDBSQLServer.FK_AKSES))
    private AksesMenuModel aksesMenuModel;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getNamaDepan() {
        return namaDepan;
    }

    public void setNamaDepan(String namaDepan) {
        this.namaDepan = namaDepan;
    }

    public String getNamaBelakang() {
        return namaBelakang;
    }

    public void setNamaBelakang(String namaBelakang) {
        this.namaBelakang = namaBelakang;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public AksesMenuModel getAksesMenuModel() {
        return aksesMenuModel;
    }

    public void setAksesMenuModel(AksesMenuModel aksesMenuModel) {
        this.aksesMenuModel = aksesMenuModel;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Boolean getRegistered() {
        return isRegistered;
    }

    public void setRegistered(Boolean registered) {
        isRegistered = registered;
    }
}
