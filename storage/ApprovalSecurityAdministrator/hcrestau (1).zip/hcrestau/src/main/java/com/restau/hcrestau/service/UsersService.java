package com.restau.hcrestau.service;

import com.restau.hcrestau.configuration.OtherConfig;
import com.restau.hcrestau.core.BcryptImpl;
import com.restau.hcrestau.core.Crypto;
import com.restau.hcrestau.core.IService;
import com.restau.hcrestau.core.security.JwtUtility;
import com.restau.hcrestau.dto.SearchParamDTO;
import com.restau.hcrestau.dto.transaksi.GetDataTransaksiDTO;
import com.restau.hcrestau.dto.users.GetUsersDTO;
import com.restau.hcrestau.dto.users.UserPaginationDTO;
import com.restau.hcrestau.handler.ResponseHandler;
import com.restau.hcrestau.model.AksesMenuModel;
import com.restau.hcrestau.model.UsersModel;
import com.restau.hcrestau.repo.AksesMenuRepo;
import com.restau.hcrestau.repo.UsersRepo;
import com.restau.hcrestau.util.ExecuteSMTP;
import com.restau.hcrestau.util.LoggingFile;
import com.restau.hcrestau.util.TransformToDTO;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.*;

@Service
@Transactional
public class UsersService implements IService<UsersModel>, UserDetailsService {
    private Map<String,Object> mapz = new HashMap<>();
    private StringBuilder sBuild = new StringBuilder();
    private String[] strExceptionArr = new String[2];

    TransformToDTO transformToDTO = new TransformToDTO();
    Map<String,Object> mapResult = new HashMap<>();
    private List<SearchParamDTO> listSearchParamDTO  = new ArrayList<>();

    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private UsersRepo userRepo;
    @Autowired
    private AksesMenuRepo aksesMenuRepo;
    @Autowired
    private JwtUtility jwtUtility;


    @Override
    public ResponseEntity<Object> save(UsersModel usersModel, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> saveBatch(List<UsersModel> lt, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> edit(Long id, UsersModel user, HttpServletRequest request) {
        if(user == null){
            return new ResponseHandler().generateResponse(
                    "Data tidak Valid",//message
                    HttpStatus.BAD_REQUEST,//httpstatus
                    null,//object
                    "FVRGS001",//errorCode Fail Validation modul-code RGS sequence 001 range 001 - 010
                    request
            );
        }

        Optional<UsersModel> optionalUsersModel = userRepo.findById(id);

        try{
            if(optionalUsersModel.isEmpty()){
                return new ResponseHandler().generateResponse("Data Tidak Ditemukan/Kosong",
                        HttpStatus.BAD_REQUEST,
                        null,
                        "FV01021", request);//FAILED VALIDATION
            }

            UsersModel uM = optionalUsersModel.get();

            var aksesMenu = aksesMenuRepo.findTop1ById(user.getAksesMenuModel().getId());
            if (aksesMenu.isEmpty())
            {
                return new ResponseHandler().generateResponse("Akses Tidak Tersedia!",
                        HttpStatus.BAD_REQUEST,null,"FVRGS002",request);
            }

            if(user.getEmail() != null){
                uM.setEmail(user.getEmail());
            }
            if(user.getNamaDepan() != null){
                uM.setNamaDepan(user.getNamaDepan());
            }
            if(user.getNamaBelakang() != null){
                uM.setNamaBelakang(user.getNamaBelakang());
            }
            if (user.getAksesMenuModel() != null) {
                uM.setAksesMenuModel(user.getAksesMenuModel());
            }

            uM.setUpdatedDate(new Date());

            userRepo.save(uM);
        }catch (Exception e){
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan",
                    HttpStatus.BAD_REQUEST,
                    e.getMessage(),
                    "FV01021", request);//FAILED VALIDATION
        }


        return new ResponseHandler().generateResponse("Berhasil Disimpan!!",
                HttpStatus.OK,
                "Sukses update!",
                null, request);
    }

    @Override
    public ResponseEntity<Object> delete(Long id, HttpServletRequest request) {
        Optional<UsersModel> optionalUsersModel = userRepo.findById(id);
        if(optionalUsersModel.isEmpty()){
            return new ResponseHandler().generateResponse(
                    "User not found",//message
                    HttpStatus.NOT_FOUND,//httpstatus
                    null,//object
                    "FVRGS001",//errorCode Fail Validation modul-code RGS sequence 001 range 001 - 010
                    request
            );
        }

        userRepo.deleteById(id);

        return new ResponseHandler().generateResponse(
                "User successfully deleted",//message
                HttpStatus.OK,//httpstatus
                null,//object
                null,//errorCode
                request
        );
    }


    @Override
    public ResponseEntity<Object> findById(Long id, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> find(Pageable pageable, String columFirst, String valueFirst, HttpServletRequest request) {
        Page<UsersModel> pageUser = null;
        List<UsersModel> listUser = null;

        if(columFirst.equals("id"))
        {
            if (valueFirst.equals("") && valueFirst!=null){
                try{
                    Long.parseLong(valueFirst);
                }catch(Exception e){
                    return new ResponseHandler().
                            generateResponse("DATA FILTER TIDAK SESUAI FORMAT HARUS ANGKA",
                                    HttpStatus.INTERNAL_SERVER_ERROR,
                                    null,//perubahan 21-12-2023
                                    "X-99-001",
                                    request);

                }

            }
        }

        pageUser = getDataByValue(pageable,columFirst,valueFirst);
        listUser = pageUser.getContent();
        if(listUser.isEmpty())
        {
            return new ResponseHandler().
                    generateResponse("DATA TIDAK DITEMUKAN",
                            HttpStatus.NOT_FOUND,
                            null,//perubahan 21-12-2023
                            "X-99-002",
                            request);
        }

        List<UserPaginationDTO>ltUserDTO =
        modelMapper.map(listUser, new TypeToken<List<UserPaginationDTO>>() {}.getType());
        mapResult = transformToDTO.transformObject(mapResult,
                ltUserDTO,
                pageUser,
                columFirst,
                valueFirst,
                listSearchParamDTO);

        return  new ResponseHandler().
                generateResponse("OK",
                        HttpStatus.OK,
                        mapResult,
                        null,
                        request);
    }

    public ResponseEntity<Object> checkRegis(UsersModel user, HttpServletRequest request) {//RANGE RGS 001-010
        if(user==null)
        {
            return new ResponseHandler().generateResponse(
                    "Data tidak Valid",//message
                    HttpStatus.BAD_REQUEST,//httpstatus
                    null,//object
                    "FVRGS001",//errorCode Fail Validation modul-code RGS sequence 001 range 001 - 010
                    request
            );
        }
        int intVerification = new Random().nextInt(100000,999999);//TOKEN YANG AKAN DIKIRIM KE EMAIL
        Optional<UsersModel> opUserResult = userRepo.findTop1ByEmail(user.getEmail());//INI VALIDASI USER IS EXISTS

        try{
            if(opUserResult.isPresent())//kondisi mengecek apakah user sudah terdaftar artinya user baru atau sudah ada
            {
                return new ResponseHandler().generateResponse("EMAIL SUDAH TERDAFTAR !!",
                        HttpStatus.NOT_ACCEPTABLE,null,"FVRGS002",request);//EMAIL SUDAH TERDAFTAR DAN AKTIF
            }

            var aksesMenu = aksesMenuRepo.findTop1ById(user.getAksesMenuModel().getId());
            if (aksesMenu.isEmpty())
            {
                return new ResponseHandler().generateResponse("AKSES TIDAK TERSEDIA !!",
                        HttpStatus.BAD_REQUEST,null,"FVRGS002",request);//EMAIL SUDAH TERDAFTAR DAN AKTIF
            }

            user.setAksesMenuModel(aksesMenu.get());

            user.setPass(BcryptImpl.hash(user.getPass()+user.getNamaDepan() + user.getNamaBelakang()));
            user.setToken(BcryptImpl.hash(String.valueOf(intVerification)));
            user.setAksesMenuModel(user.getAksesMenuModel());
            user.setRegistered(false);
            user.setCreatedDate(new Date());
            userRepo.save(user);


            String[] strVerify = new String[4];
            strVerify[0] = "Verifikasi Email";
            strVerify[1] = user.getNamaDepan()+user.getNamaBelakang();
            strVerify[2] = String.valueOf(intVerification);
            strVerify[3] = String.valueOf(intVerification);

            /**
             method untuk kirim email
             */
            Thread first = new Thread(new Runnable() {
                @Override
                public void run() {
                    new ExecuteSMTP().
                            sendSMTPToken(
                                    user.getEmail(),// email tujuan
                                    "TOKEN Verifikasi Email",// judul email
                                    strVerify,//
                                    "ver_regis.html");// \\data\\ver_regis
                    System.out.println("Email Terkirim");
                }
            });
            first.start();
        } catch (Exception e)
        {
//            strExceptionArr[1] = "checkRegis(User user, HttpServletRequest request)  --- LINE 130 \n ALL - REQUEST"+ RequestCapture.allRequest(request);
//            LoggingFile.exceptionStringz(strExceptionArr, e, OtherConfig.getFlagLoging());
//            LogTable.inputLogRequest(strExceptionArr,e, OtherConfig.getFlagLogTable());
            return new ResponseHandler().generateResponse("GAGAL DIPROSES",HttpStatus.INTERNAL_SERVER_ERROR,null,"FERGS001",request);
        }

        Map<String,Object> map = new HashMap<String,Object>();
        map.put("token",authManagerRegister(user,request));

        return new ResponseHandler().generateResponse("TOKEN TERKIRIM",
                HttpStatus.CREATED,map,null,request);
    }

    public ResponseEntity<Object> doLogin(UsersModel userz, HttpServletRequest request) {

        userz.setEmail(userz.getEmail());
        Optional<UsersModel> opUserResult = userRepo.findTop1ByEmail(userz.getEmail());//DATANYA PASTI HANYA 1
        UsersModel nextUser = null;

        try
        {
            if(opUserResult.isPresent())
            {
                nextUser = opUserResult.get();
                if(!BcryptImpl.verifyHash(userz.getPass()+nextUser.getNamaDepan()+nextUser.getNamaBelakang(),nextUser.getPass()))//dicombo dengan userName
                {
                    return new ResponseHandler().generateResponse("LOGIN GAGAL BRO / SIS !!",
                            HttpStatus.NOT_ACCEPTABLE,null,"FV01004",request);
                }else if(!nextUser.getRegistered().equals(true))
                {

                    return new ResponseHandler().generateResponse("User Belum Terverifikasi",
                            HttpStatus.NOT_ACCEPTABLE,null,"FV01006",request);
                }
                Integer intUserId = Integer.parseInt(String.valueOf(nextUser.getId()));
                /**
                 * Ketiga Informasi ini kalau butuh dibuatan saja di Model User nya
                 * kalau digunakan pastikan flow nya di check lagi !!
                 */
//                nextUser.setLastLoginDate(new Date());
//                nextUser.setTokenCounter(0);//SETIAP KALI LOGIN BERHASIL , BERAPA KALIPUN UJI COBA REQUEST TOKEN YANG SEBELUMNYA GAGAL AKAN SECARA OTOMATIS DIRESET MENJADI 0
//                nextUser.setPasswordCounter(0);//SETIAP KALI LOGIN BERHASIL , BERAPA KALIPUN UJI COBA YANG SEBELUMNYA GAGAL AKAN SECARA OTOMATIS DIRESET MENJADI 0
                nextUser.setUpdatedBy(nextUser.getEmail());
                nextUser.setUpdatedDate(new Date());
            }
            else
            {
                return new ResponseHandler().generateResponse("User Tidak Terdaftar",
                        HttpStatus.NOT_ACCEPTABLE,null,"FV01005",request);
            }
        }

        catch (Exception e)
        {
//            strExceptionArr[1]="doLogin(Userz userz,WebRequest request)  --- LINE 132";
//            LoggingFile.exceptionStringz(strExceptionArr,e, OtherConfig.getFlagLoging());
            return new ResponseHandler().generateResponse("Error",
                    HttpStatus.INTERNAL_SERVER_ERROR,null,"FE04003",request);
        }

        Map<String,Object> map = new HashMap<String,Object>();
        map.put("token",authManager(nextUser,request));
        map.put("rahasia",nextUser.getId());

        /*
            Transform dari List Menu Header
         */
        /*
            Transform dari List Menu Header
         */

//        List<Menu> listMenu = nextUser.getAkses().getLtMenu();
////        List<MenuResponse3DTO> ltMenuDTO = modelMapper.map(listMenu,new TypeToken<List<MenuResponse3DTO>>(){}.getType());
//        if(!listMenu.isEmpty())
//        {
//
//            map.put("menu",new TransformationData().doTransformAksesMenuLogin(listMenu));
//        }else {
//            map.put("menu",new ArrayList<>());
//        }
        return new ResponseHandler().generateResponse("Login Berhasil",
                HttpStatus.OK,map,null,request);
    }

    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException { //by email

            /**
             WARNING !!
             username yang ada di parameter otomatis hanya username , bukan string yang di kombinasi dengan password atau informasi lainnya...
             userName yang ada di parameter belum tentu adalah username...
             karena sistem memperbolehkan login dengan email, nohp ataupun username
             pastikan harus mengecek flag user teregistrasi atau belum
             */
            Optional<UsersModel> opUser = userRepo.findTop1ByEmail(s);
            if(opUser.isEmpty())
            {
                throw new UsernameNotFoundException("no user");
            }
            UsersModel userNext = opUser.get();
            /**
             PARAMETER KE 3 TIDAK MENGGUNAKAN ROLE DARI SPRINGSECURITY CORE
             ROLE MODEL AKAN DITAMBAHKAN DI METHOD authManager DAN DIJADIKAN INFORMASI DI DALAM JWT AGAR LEBIH DINAMIS
             */
            return new org.springframework.security.core.userdetails.
                    User(userNext.getEmail(),userNext.getPass(),new ArrayList<>());
    }

    public String authManager(UsersModel user, HttpServletRequest request)//RANGE 006-010
    {
        /* Untuk memasukkan user ke dalam */
        sBuild.setLength(0);
        UserDetails userDetails = loadUserByUsername(user.getEmail());
        if(userDetails==null)
        {
            return "FAILED";
        }

        /* Isi apapun yang perlu diisi ke dalam object mapz !! */
        mapz.put("uid",user.getId());
        mapz.put("ml",user.getEmail());//5-6-10

        Optional<UsersModel> optionalUser = userRepo.findTop1ByEmail(user.getEmail());
        String token = jwtUtility.generateToken(userDetails,mapz);
        token = Crypto.performEncrypt(token);

        return token;
    }

    public String authManagerRegister(UsersModel user, HttpServletRequest request)//RANGE 006-010
    {
        /* Untuk memasukkan user ke dalam */
        sBuild.setLength(0);
        UserDetails userDetails = loadUserByUsername(user.getEmail());
        if(userDetails==null)
        {
            return "FAILED";
        }

        /* Isi apapun yang perlu diisi ke dalam object mapz !! */
        mapz.put("uid",user.getId());
        mapz.put("ml",user.getEmail());//5-6-10
        mapz.put("nd",user.getNamaDepan());
        mapz.put("nb",user.getNamaBelakang());

        Optional<UsersModel> optionalUser = userRepo.findTop1ByEmail(user.getEmail());
        String token = jwtUtility.generateRegisterToken(userDetails,mapz);
        token = Crypto.performEncrypt(token);

        return token;
    }

    public ResponseEntity<Object> getAll(HttpServletRequest request) {
        List<UsersModel> users = userRepo.findAll();
        return new ResponseHandler().generateResponse(
                "Data berhasil diambil",//message
                HttpStatus.OK,//httpstatus
                users,//object
                null,//errorCode
                request
        );
    }

    public ResponseEntity<Object> getUserById(Long id, HttpServletRequest request) {
        Optional<UsersModel> user = userRepo.findById(id);
        if(user.isEmpty()){
            return new ResponseHandler().generateResponse(
                    "User not found",//message
                    HttpStatus.NOT_FOUND,//httpstatus
                    null,//object
                    "FVRGS001",//errorCode Fail Validation modul-code RGS sequence 001 range 001 - 010
                    request
            );
        }

        UsersModel usersModel = user.get();
        Optional<AksesMenuModel> aksesMenuModel = aksesMenuRepo.findTop1ById(usersModel.getAksesMenuModel().getId());

        GetUsersDTO getUsersDTO = modelMapper.map(usersModel, new TypeToken<GetUsersDTO>() {}.getType());
        getUsersDTO.setIdAkses(aksesMenuModel.get().getId());
        getUsersDTO.setNamaAkses(aksesMenuModel.get().getNamaAkses());
        return new ResponseHandler().generateResponse(
                "Data berhasil diambil",//message
                HttpStatus.OK,//httpstatus
                getUsersDTO,//object
                null,//errorCode
                request
        );
    }


    public ResponseEntity<Object> inputToken(UsersModel user, HttpServletRequest request) {
        if(user==null)
        {
            return new ResponseHandler().generateResponse("Data Tidak Valid",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }

        String jwt = request.getHeader("Authorization");
        jwt = new Crypto().performDecrypt(jwt.substring(7));
        try {
            jwt = jwtUtility.getUsernameFromToken(jwt);
        } catch (Exception e) {
            strExceptionArr[1]="doVerification(UsersModel user, HttpServletRequest request)  --- LINE 231";
            LoggingFile.exceptionStringz(strExceptionArr,e, OtherConfig.getFlagLoging());
        }

//        user.setUsername(jwt);

        Optional<UsersModel> opUserResult = userRepo.findTop1ByEmail(jwt);
        UsersModel nextUser = null;
        try
        {
            if(!opUserResult.isEmpty())
            {
                nextUser = opUserResult.get();
                if(!BcryptImpl.verifyHash(user.getToken(),nextUser.getToken()))//comparing kiri token dimasukin, kanan token db
                {
                    return new ResponseHandler().generateResponse("OTP yang anda input salah, silahkan dicoba kembali!!",
                            HttpStatus.NOT_ACCEPTABLE,null,"FV01007",request);
                }
            }
            else
            {
                return new ResponseHandler().generateResponse("Username atau password salah!!",
                        HttpStatus.NOT_ACCEPTABLE,null,"FV01008",request);
            }
        }

        catch (Exception e)
        {
            return new ResponseHandler().generateResponse("Error",
                    HttpStatus.INTERNAL_SERVER_ERROR,null,"FE04003",request);
        }

        nextUser.setRegistered(true);

        return new ResponseHandler().generateResponse("Login Berhasil",
                HttpStatus.CREATED,null,null,request);


    }


    //Filter based on akses Menu = 2
    private Page<UsersModel> getDataByValue(Pageable pageable, String columnFirst, String valueFirst) {
        Specification<UsersModel> spec = Specification.where((root, query, cb) -> cb.equal(root.get("aksesMenuModel").get("id"), 2));

        if(valueFirst.equals("") || valueFirst==null)
        {
            return userRepo.findAll(spec, pageable);
        }

        if (columnFirst.equals("namaDepan")) {
            spec = spec.and((root, query, cb) -> cb.like(cb.lower(root.get("namaDepan")), "%" + valueFirst.toLowerCase() + "%"));
        } else if (columnFirst.equals("namaBelakang")) {
            spec = spec.and((root, query, cb) -> cb.like(cb.lower(root.get("namaBelakang")), "%" + valueFirst.toLowerCase() + "%"));
        } else if (columnFirst.equals("createdDate")) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("createdDate"), LocalDateTime.parse(valueFirst)));
        } else if(columnFirst.equals("id")) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("id"), Long.parseLong(valueFirst)));
        } else if(columnFirst.equals("email")) {
            spec = spec.and((root, query, cb) -> cb.like(cb.lower(root.get("email")), "%" + valueFirst.toLowerCase() + "%"));
        }
        return userRepo.findAll(spec, pageable);
    }


    //bikin OTP baru, user masukin OTP baru dan dibikin bearer token baru

}
