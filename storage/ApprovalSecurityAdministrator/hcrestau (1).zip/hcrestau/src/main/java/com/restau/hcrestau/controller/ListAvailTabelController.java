package com.restau.hcrestau.controller;

import com.restau.hcrestau.dto.tabel.ListAvailTabelDTO;
import com.restau.hcrestau.model.ListAvailTabelModel;
import com.restau.hcrestau.service.ListAvailTabelService;
import org.apache.coyote.Response;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/avail-tabel")
public class ListAvailTabelController {

    @Autowired
    private ListAvailTabelService listAvailTabelService;

    @Autowired
    private ModelMapper modelMapper;

    private Map<String,String> mapSorting = new HashMap<String,String>();
    public ListAvailTabelController() {
        mapSorting();
    }

    private void mapSorting()
    {
        mapSorting.put("id","id");
        mapSorting.put("isAvail","isAvail");
        mapSorting.put("createdDate","createdDate");
    }


    @PostMapping("/v1/create")
    public ResponseEntity<Object> save(@RequestBody ListAvailTabelModel listAvailTabelModel,
                                       HttpServletRequest request){
        return listAvailTabelService.save(listAvailTabelModel,request);
    }

    @PutMapping("/v1/edit/{id}")
    public ResponseEntity<Object> edit(@PathVariable(value = "id") Long id,
                                       @RequestBody @Valid ListAvailTabelDTO listAvailTabelDTO,
                                       HttpServletRequest request){
        ListAvailTabelModel listAvailTabelModel = modelMapper.map(listAvailTabelDTO, new TypeToken<ListAvailTabelModel>() {}.getType());
        return listAvailTabelService.edit(id,listAvailTabelModel,request);
    }

    @DeleteMapping("/v1/delete/{id}")
    public ResponseEntity<Object> delete(@PathVariable(value = "id") Long id,
                                         HttpServletRequest request){
        return listAvailTabelService.delete(id,request);
    }

    @GetMapping("/v1/get-all")
    public ResponseEntity<Object> getAll(HttpServletRequest request) {
        return listAvailTabelService.getAll(request);
    }

    @GetMapping("/v1/get-tabel/{page}/{sort}/{sortBy}")
    public ResponseEntity<Object> find(@PathVariable(value = "page") Integer page,
                                       @PathVariable(value = "sort") String sort,
                                       @PathVariable(value = "sortBy") String sortBy,
                                       @RequestParam("filterBy") String filterBy,
                                       @RequestParam("value") String value,
                                       @RequestParam("size") String size,
                                       HttpServletRequest request){
        Pageable pageable = null;
        page = page==null?0:page;
        sortBy = (sortBy==null || sortBy.equals(""))?"id":sortBy;
        sort   = (sort==null || sort.equals("") || sort.equals("asc"))?"asc":"desc";

        sortBy = mapSorting.get(sortBy);
        pageable = PageRequest.of(page,Integer.parseInt(size.equals("")?"10":size),
                sort.equals("desc")? Sort.by(sortBy).descending():Sort.by(sortBy));

        return listAvailTabelService.find(pageable,filterBy,value,request);
    }



}
