package com.restau.hcrestau.constant;

public class ScriptDBSQLServer {
    public static final String FK_AKSES = "FOREIGN KEY ([IdAkses]) REFERENCES [RestAu].[AksesMenu] ([IdAkses]) ON DELETE CASCADE ON UPDATE NO ACTION";

    public static final String FK_LISTMENU = "FOREIGN KEY ([IdListMenu]) REFERENCES [RestAu].[ListMenu] ([IdListMenu]) ON DELETE CASCADE ON UPDATE NO ACTION";
    public static final String FK_JENISMENU = "FOREIGN KEY ([IdJenisMenu]) REFERENCES [RestAu].[JenisMenu] ([IdJenisMenu]) ON DELETE CASCADE ON UPDATE NO ACTION";
    public static final String FK_LISTTABEL = "FOREIGN KEY ([IdTabel]) REFERENCES [RestAu].[ListTabel] ([IdTabel]) ON DELETE CASCADE ON UPDATE NO ACTION";

    public static final String FK_ORDER = "FOREIGN KEY ([IdOrder]) REFERENCES [RestAu].[ListOrder] ([IdOrder]) ON DELETE CASCADE ON UPDATE NO ACTION";

    public static final String FK_USER = "FOREIGN KEY ([IdUser]) REFERENCES [RestAu].[Users] ([IdUser]) ON DELETE CASCADE ON UPDATE NO ACTION";

    public static final String FK_TABEL = "FOREIGN KEY ([IdTabel]) REFERENCES [RestAu].[ListAvailTabel] ([IdTabel]) ON DELETE CASCADE ON UPDATE NO ACTION";
}
