package com.restau.hcrestau.repo;

import com.restau.hcrestau.model.AksesMenuModel;
import com.restau.hcrestau.model.UsersModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AksesMenuRepo extends JpaRepository<AksesMenuModel,Long> {
    Optional<AksesMenuModel> findTop1ById(Long id);

    Optional<AksesMenuModel> findByNamaAkses(String namaAkses);

}
