package com.restau.hcrestau.repo;

import com.restau.hcrestau.model.JenisMenuModel;
import com.restau.hcrestau.model.ListStrukModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ListStrukRepo extends JpaRepository<ListStrukModel,Long> {
    Page<ListStrukModel> findByIdContainingIgnoreCase(Pageable pageable, Long id);
    Page<ListStrukModel> findByNamaKustomerContainingIgnoreCase(Pageable pageable, String namaKustomer);

}
