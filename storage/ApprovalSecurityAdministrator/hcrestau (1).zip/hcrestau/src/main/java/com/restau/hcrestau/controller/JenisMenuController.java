package com.restau.hcrestau.controller;

import com.restau.hcrestau.dto.jenis.JenisMenuDTO;
import com.restau.hcrestau.model.JenisMenuModel;
import com.restau.hcrestau.service.JenisMenuService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/jenis-menu")
public class JenisMenuController {
    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private JenisMenuService jenisMenuService;

    private Map<String,String> mapSorting = new HashMap<String,String>();
    public JenisMenuController() {
        mapSorting();
    }

    private void mapSorting()
    {
        mapSorting.put("id","id");
        mapSorting.put("namaJenis","namaJenis");
        mapSorting.put("createdDate","createdDate");
    }


    @PostMapping("/v1/create")
    public ResponseEntity<Object> save(@RequestBody @Valid JenisMenuDTO jenisMenuDTO, HttpServletRequest request){
        JenisMenuModel jenisMenu = modelMapper.map(jenisMenuDTO, JenisMenuModel.class);
        return jenisMenuService.save(jenisMenu,request);
    }

    @PutMapping("/v1/edit/{id}")
    public ResponseEntity<Object> edit(@PathVariable(value = "id") Long id, @RequestBody @Valid JenisMenuDTO jenisMenuDTO, HttpServletRequest request){
        JenisMenuModel jenisMenu = modelMapper.map(jenisMenuDTO, JenisMenuModel.class);
        return jenisMenuService.edit(id,jenisMenu,request);
    }

    @DeleteMapping("/v1/delete/{id}")
    public ResponseEntity<Object> delete(@PathVariable(value = "id") Long id, HttpServletRequest request){
        return jenisMenuService.delete(id,request);
    }

    @GetMapping("/v1/get-all")
    public ResponseEntity<Object> getAll(HttpServletRequest request){
        return jenisMenuService.getAll(request);
    }

    @GetMapping("/v1/get-jenis/{page}/{sort}/{sortBy}")
    public ResponseEntity<Object> find(@PathVariable(value = "page") Integer page,
                                       @PathVariable(value = "sort") String sort,
                                       @PathVariable(value = "sortBy") String sortBy,
                                       @RequestParam("filterBy") String filterBy,
                                       @RequestParam("value") String value,
                                       @RequestParam("size") String size,
                                       HttpServletRequest request){
        Pageable pageable = null;
        page = page==null?0:page;
        sortBy = (sortBy==null || sortBy.equals(""))?"id":sortBy;
        sort   = (sort==null || sort.equals("") || sort.equals("asc"))?"asc":"desc";

        sortBy = mapSorting.get(sortBy);
        pageable = PageRequest.of(page,Integer.parseInt(size.equals("")?"10":size),
                sort.equals("desc")? Sort.by(sortBy).descending():Sort.by(sortBy));

        return jenisMenuService.find(pageable,filterBy,value,request);
    }

}
