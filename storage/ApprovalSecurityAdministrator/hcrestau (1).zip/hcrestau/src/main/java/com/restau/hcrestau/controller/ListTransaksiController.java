package com.restau.hcrestau.controller;

import com.restau.hcrestau.dto.menu.MenuDTO;
import com.restau.hcrestau.dto.struk.InputListStrukDTO;
import com.restau.hcrestau.dto.transaksi.ListTransaksiDTO;
import com.restau.hcrestau.model.*;
import com.restau.hcrestau.service.ListStrukService;
import com.restau.hcrestau.service.ListTransaksiService;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.modelmapper.convention.MatchingStrategies;
import org.modelmapper.spi.MatchingStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/list-transaksi")
public class ListTransaksiController {

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private ListTransaksiService listTransaksiService;

    private Map<String,String> mapSorting = new HashMap<String,String>();
    public ListTransaksiController() {
        mapSorting();
    }

    private void mapSorting()
    {
        mapSorting.put("id","id");
        mapSorting.put("hargaMenu","hargaMenu");
        mapSorting.put("jumlahMenu","jumlahMenu");
        mapSorting.put("totalHarga","totalHarga");
        mapSorting.put("namaKustomer","namaKustomer");
        mapSorting.put("namaMenu","namaMenu");
        mapSorting.put("cooked","cooked");
        mapSorting.put("namaDepan","namaDepan");
        mapSorting.put("namaBelakang","namaBelakang");
    }

    @PostMapping("/v1/create")
    public ResponseEntity<Object> save(@RequestBody ListTransaksiDTO listTransaksiDTO,
                                           HttpServletRequest request){

        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        ListTransaksiModel listTransaksiModel = modelMapper.map(listTransaksiDTO, new TypeToken<ListTransaksiModel>() {}.getType());


        //Mapping to ListStrukModel from ListTransaksiDTO
        ListStrukModel listStrukModel = new ListStrukModel();
        listStrukModel.setId(listTransaksiDTO.getIdStruk());

        //Mapping to MenuModel from ListTransaksiDTO
        MenuModel menuModel = new MenuModel();
        menuModel.setIdMenu(listTransaksiDTO.getIdMenu());

        //Set each model to ListTransaksiModel
        listTransaksiModel.setListStrukModel(listStrukModel);
        listTransaksiModel.setMenuModel(menuModel);

        return listTransaksiService.save(listTransaksiModel,request);
    }

    @PutMapping("/v1/cooked/{id}/{idUser}")
    public ResponseEntity<Object> cooked(@PathVariable(value = "id") Long id,
                                         @PathVariable(value = "idUser") Long idUser,
                                         HttpServletRequest request){
        return listTransaksiService.cooked(id,idUser,request);
    }

    @DeleteMapping("/v1/delete/{id}")
    public ResponseEntity<Object> delete(@PathVariable(value = "id") Long id, HttpServletRequest request){
        return listTransaksiService.delete(id,request);
    }

    @GetMapping("/v1/get-all")
    public ResponseEntity<Object> getAll(HttpServletRequest request){

        return listTransaksiService.getAll(request);
    }

    @GetMapping("/v1/get-transaksi/{page}/{sort}/{sortBy}")
    public ResponseEntity<Object> find(@PathVariable(value = "page") Integer page,
                                       @PathVariable(value = "sort") String sort,
                                       @PathVariable(value = "sortBy") String sortBy,
                                       @RequestParam("filterBy") String filterBy,
                                       @RequestParam("value") String value,
                                       @RequestParam("size") String size,
                                       HttpServletRequest request){
        Pageable pageable = null;
        page = page==null?0:page;
        sortBy = (sortBy==null || sortBy.equals(""))?"id":sortBy;
        sort   = (sort==null || sort.equals("") || sort.equals("asc"))?"asc":"desc";

        sortBy = mapSorting.get(sortBy);
        pageable = PageRequest.of(page,Integer.parseInt(size.equals("")?"10":size),
                sort.equals("desc")? Sort.by(sortBy).descending():Sort.by(sortBy));

        return listTransaksiService.find(pageable,filterBy,value,request);
    }

    @GetMapping("/v1/get-transaksi/{id}")
    public ResponseEntity<Object> getTransaksiById(@PathVariable(value = "id") Long id, HttpServletRequest request){
        return listTransaksiService.getTransaksiById(id, request);
    }
}
