package com.restau.hcrestau.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.restau.hcrestau.dto.AksesMenuDTO;
import com.restau.hcrestau.dto.auth.RegisDTO;
//import com.restau.hcrestau.dto.map.MapAksesMenuDTO;
import com.restau.hcrestau.model.AksesMenuModel;
import com.restau.hcrestau.model.UsersModel;
import com.restau.hcrestau.service.AksesMenuService;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("/api/akses")
public class AksesMenuController {

    @Autowired
    private AksesMenuService aksesMenuService;



    @Autowired
    private ObjectMapper modelMapper;

    @PostMapping("/v1/create")
    public ResponseEntity<Object> save(@RequestBody @Valid AksesMenuDTO aksesMenuDTO, HttpServletRequest request)
    {
        AksesMenuModel aksesMenu = modelMapper.convertValue(aksesMenuDTO, AksesMenuModel.class);
        return aksesMenuService.save(aksesMenu,request);
    }

    @PutMapping("/v1/edit/{id}")
    public ResponseEntity<Object> assign(@PathVariable(value = "id") Long id, @RequestBody @Valid AksesMenuDTO aksesMenuDTO , HttpServletRequest request){

        AksesMenuModel aksesMenu = modelMapper.convertValue(aksesMenuDTO, AksesMenuModel.class);
        return aksesMenuService.edit(id,aksesMenu,request);

    }

    @DeleteMapping("/v1/delete/{id}")
    public ResponseEntity<Object> delete(@PathVariable(value = "id") Long id, HttpServletRequest request){
        return aksesMenuService.delete(id,request);
    }



    @GetMapping("/v1/get-all")
    public ResponseEntity<Object> getAkses(HttpServletRequest request){
        return aksesMenuService.getAll(request);
    }



}
