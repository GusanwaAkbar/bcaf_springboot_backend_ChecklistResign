package com.restau.hcrestau.dto.users;

import com.restau.hcrestau.model.AksesMenuModel;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class UsersDTO {

    @NotNull
    @NotBlank
    @NotEmpty
    private String email;

    @NotNull
    @NotBlank
    @NotEmpty
    private String namaDepan;

    @NotNull
    @NotBlank
    @NotEmpty
    private String namaBelakang;

    @NotNull
    private Long akses;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNamaDepan() {
        return namaDepan;
    }

    public void setNamaDepan(String namaDepan) {
        this.namaDepan = namaDepan;
    }

    public String getNamaBelakang() {
        return namaBelakang;
    }

    public void setNamaBelakang(String namaBelakang) {
        this.namaBelakang = namaBelakang;
    }

    public Long getAkses() {
        return akses;
    }

    public void setAkses(Long akses) {
        this.akses = akses;
    }

}
