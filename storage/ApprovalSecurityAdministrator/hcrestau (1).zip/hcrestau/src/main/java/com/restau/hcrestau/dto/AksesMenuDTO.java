package com.restau.hcrestau.dto;

import com.restau.hcrestau.model.ListMenuModel;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

public class AksesMenuDTO {

    @NotNull(message = "namaAkses TIDAK BOLEH NULL")
    @NotBlank(message = "namaAkses TIDAK BOLEH BLANK")
    @NotEmpty(message = "namaAkses TIDAK BOLEH EMPTY")
    private String namaAkses;

    private List<ListMenuModel> ltMenuModel;

    public String getNamaAkses() {
        return namaAkses;
    }

    public List<ListMenuModel> getLtMenuModel() {
        return ltMenuModel;
    }

    public void setLtMenuModel(List<ListMenuModel> ltMenuModel) {
        this.ltMenuModel = ltMenuModel;
    }

    public void setNamaAkses(String namaAkses) {
        this.namaAkses = namaAkses;
    }
}
