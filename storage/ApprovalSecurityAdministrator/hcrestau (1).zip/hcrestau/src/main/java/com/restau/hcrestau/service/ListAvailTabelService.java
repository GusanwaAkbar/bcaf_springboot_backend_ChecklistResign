package com.restau.hcrestau.service;

import com.restau.hcrestau.core.IService;
import com.restau.hcrestau.dto.SearchParamDTO;
import com.restau.hcrestau.dto.tabel.TabelPaginationDTO;
import com.restau.hcrestau.dto.users.UserPaginationDTO;
import com.restau.hcrestau.handler.ResponseHandler;
import com.restau.hcrestau.model.ListAvailTabelModel;
import com.restau.hcrestau.model.UsersModel;
import com.restau.hcrestau.repo.ListAvailTabelRepo;
import com.restau.hcrestau.util.TransformToDTO;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Service
public class ListAvailTabelService implements IService<ListAvailTabelModel> {
    @Autowired
    private ListAvailTabelRepo listAvailTabelRepo;
    @Autowired
    private ModelMapper modelMapper;

    Map<String,Object> mapResult = new HashMap<>();
    TransformToDTO transformToDTO = new TransformToDTO();
    private List<SearchParamDTO> listSearchParamDTO  = new ArrayList<>();

    @Override
    public ResponseEntity<Object> save(ListAvailTabelModel listAvailTabelModel, HttpServletRequest request) {
        if(listAvailTabelModel==null)
        {
            return new ResponseHandler().generateResponse("Data Tidak Valid",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }

        try{
            listAvailTabelRepo.save(listAvailTabelModel);
        }catch (Exception e){
            return new ResponseHandler().generateResponse("Data Gagal Disimpan",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    null,
                    "FE01002", request);//FAILED ERROR
        }

        return new ResponseHandler().generateResponse("Berhasil Disimpan!",
                HttpStatus.CREATED,
                null,
                "SC01001", request);//SUCCESS CREATED
    }

    @Override
    public ResponseEntity<Object> saveBatch(List<ListAvailTabelModel> lt, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> edit(Long id, ListAvailTabelModel listAvailTabelModel, HttpServletRequest request) {
        Optional<ListAvailTabelModel> optionalListAvailTabelModel = listAvailTabelRepo.findById(id);

        if(optionalListAvailTabelModel.isEmpty())
        {
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan",
                    HttpStatus.NOT_FOUND,
                    null,
                    "FE01004", request);//FAILED ERROR
        }

        ListAvailTabelModel oLAT = optionalListAvailTabelModel.get();

        if(listAvailTabelModel.getAvail()!=null)
        {
            oLAT.setAvail(listAvailTabelModel.getAvail());
        }

        oLAT.setUpdatedDate(new Date());

        listAvailTabelRepo.save(oLAT);

        return new ResponseHandler().generateResponse("Berhasil Diubah!",
                HttpStatus.OK,
                "Sukses update!",
                "SC01002", request);//SUCCESS UPDATED

    }

    @Override
    public ResponseEntity<Object> delete(Long id, HttpServletRequest request) {
        Optional<ListAvailTabelModel> optionalListAvailTabelModel = listAvailTabelRepo.findById(id);

        if(optionalListAvailTabelModel.isEmpty())
        {
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan/Kosong",
                    HttpStatus.NOT_FOUND,
                    null,
                    "FE01004", request);//FAILED ERROR
        }

        ListAvailTabelModel oLAT = optionalListAvailTabelModel.get();
        listAvailTabelRepo.delete(oLAT);

        return new ResponseHandler().generateResponse("Berhasil Dihapus!",
                HttpStatus.OK,
                "Sukses delete!",
                "SC01003", request);//SUCCESS DELETED
    }

    @Override
    public ResponseEntity<Object> findById(Long id, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> getAll(HttpServletRequest request) {
        List<ListAvailTabelModel> listAvailTabelModels = listAvailTabelRepo.findAll();

        if(listAvailTabelModels.isEmpty())
        {
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan/Kosong",
                    HttpStatus.NOT_FOUND,
                    null,
                    "FE01005", request);//FAILED ERROR
        }

        return new ResponseHandler().generateResponse("Berhasil Mengambil Data!",
                HttpStatus.OK,
                listAvailTabelModels,
                "SC01004", request);//SUCCESS
    }

    @Override
    public ResponseEntity<Object> find(Pageable pageable, String columFirst, String valueFirst, HttpServletRequest request) {
        Page<ListAvailTabelModel> pageTabel = null;
        List<ListAvailTabelModel> listTabel = null;

        if(columFirst.equals("id"))
        {
            if (valueFirst.equals("") && valueFirst!=null){
                try{
                    Long.parseLong(valueFirst);
                }catch(Exception e){
                    return new ResponseHandler().
                            generateResponse("DATA FILTER TIDAK SESUAI FORMAT HARUS ANGKA",
                                    HttpStatus.INTERNAL_SERVER_ERROR,
                                    null,//perubahan 21-12-2023
                                    "X-99-001",
                                    request);
                }

            }
        }

        pageTabel = getDataByValue(pageable,columFirst,valueFirst);
        listTabel = pageTabel.getContent();
        if(listTabel.isEmpty())
        {
            return new ResponseHandler().
                    generateResponse("DATA TIDAK DITEMUKAN",
                            HttpStatus.NOT_FOUND,
                            null,//perubahan 21-12-2023
                            "X-99-002",
                            request);
        }

        List<TabelPaginationDTO>ltTabelDTO =
                modelMapper.map(listTabel, new TypeToken<List<TabelPaginationDTO>>() {}.getType());
        mapResult = transformToDTO.transformObject(mapResult,
                ltTabelDTO,
                pageTabel,
                columFirst,
                valueFirst,
                listSearchParamDTO);

        return  new ResponseHandler().
                generateResponse("OK",
                        HttpStatus.OK,
                        mapResult,
                        null,
                        request);
    }

    private Page<ListAvailTabelModel> getDataByValue(Pageable pageable, String columnFirst, String valueFirst) {
        if(valueFirst.equals("") || valueFirst==null) {
            return listAvailTabelRepo.findAll(pageable);
        }
        if(columnFirst.equals("id")){
            return listAvailTabelRepo.findById(pageable, Long.parseLong(valueFirst));
        }
        return listAvailTabelRepo.findAll(pageable);
    }
}
