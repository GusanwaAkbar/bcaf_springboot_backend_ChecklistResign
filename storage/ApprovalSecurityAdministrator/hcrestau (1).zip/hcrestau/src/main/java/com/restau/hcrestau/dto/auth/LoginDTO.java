package com.restau.hcrestau.dto.auth;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class LoginDTO {
    @NotEmpty(message = "Email Tidak Boleh Kosong")
    @NotNull(message = "Email Tidak Boleh Null")
    @NotBlank(message = "Email Tidak Boleh Mengandung Spasi")
    private String email;

    @NotEmpty(message = "Password Tidak Boleh Kosong")
    @NotNull(message = "Password Tidak Boleh Null")
    @NotBlank(message = "Password Tidak Boleh Mengandung Spasi")
    private String pass;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}
