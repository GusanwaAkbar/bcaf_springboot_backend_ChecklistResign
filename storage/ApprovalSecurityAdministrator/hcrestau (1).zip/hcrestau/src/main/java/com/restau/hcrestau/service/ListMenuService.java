package com.restau.hcrestau.service;

import com.restau.hcrestau.core.IService;
import com.restau.hcrestau.dto.menu.ListMenuDTO;
import com.restau.hcrestau.handler.ResponseHandler;
import com.restau.hcrestau.model.ListMenuModel;
import com.restau.hcrestau.repo.ListMenuRepo;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 *  Company Code - Not Necessery
 *  Modul Code 01
 *  Type of Error -> Validation = FV , Engine Error = FE
 *  ex : FE01001 (Error di Modul GroupMenu Functional Save)
 */
@Service
public class ListMenuService implements IService<ListMenuModel> {

    @Autowired
    private ListMenuRepo listMenuRepo;

    @Autowired
    private ModelMapper modelMapper;


    @Override
    public ResponseEntity<Object> save(ListMenuModel listMenuModel, HttpServletRequest request) {
        if(listMenuModel==null)
        {
            return new ResponseHandler().generateResponse("Data Tidak Valid",
                    HttpStatus.BAD_REQUEST,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }
        Optional<ListMenuModel> existingListMenuModel = listMenuRepo.findByNamaMenu(listMenuModel.getNamaMenu());
        if(existingListMenuModel.isPresent()) {
            return new ResponseHandler().generateResponse("Tidak Boleh Memasukkan Data yang sama!",
                    HttpStatus.CONFLICT,
                    null,
                    "FE01003", request);//FAILED ERROR
        }

        try{
            listMenuRepo.save(listMenuModel);
        }catch (Exception e)
        {
            return new ResponseHandler().generateResponse("Data Gagal Disimpan",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    null,
                    "FE01002", request);//FAILED ERROR
        }

        return new ResponseHandler().generateResponse("Berhasil Disimpan!",
                HttpStatus.CREATED,
                null,
                null, request);
    }


    @Override
    public ResponseEntity<Object> edit(Long id, ListMenuModel listMenuModel, HttpServletRequest request) {
        Optional<ListMenuModel> optionalListMenuModel = listMenuRepo.findById(id);

        if(optionalListMenuModel.isEmpty())
        {
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan/Kosong",
                    HttpStatus.NOT_FOUND,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }
        ListMenuModel oLM = optionalListMenuModel.get();
        if(listMenuModel.getNamaMenu()!=null)
        {
            oLM.setNamaMenu(listMenuModel.getNamaMenu());
        }

        oLM.setUpdatedDate(new Date());

        listMenuRepo.save(oLM);
        return new ResponseHandler().generateResponse("Berhasil Disimpan!",
                HttpStatus.OK,
                "Sukses update!",
                null, request);

    }

    @Override
    public ResponseEntity<Object> saveBatch(List<ListMenuModel> lt, HttpServletRequest request) {
        listMenuRepo.saveAll(lt);

        return new ResponseHandler().generateResponse("Berhasil Disimpan!",
                HttpStatus.CREATED,
                null,
                null, request);
    }


    @Override
    public ResponseEntity<Object> delete(Long id, HttpServletRequest request) {

        Optional<ListMenuModel> optionalListMenuModel = listMenuRepo.findById(id);
        if(optionalListMenuModel.isEmpty())
        {
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan/Kosong",
                    HttpStatus.NOT_FOUND,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }

        listMenuRepo.deleteById(id);
        return new ResponseHandler().generateResponse("Berhasil Dihapus!",
                HttpStatus.OK,
                "Sukses delete!",
                null, request);
    }

    @Override
    public ResponseEntity<Object> findById(Long id, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> find(Pageable pageable, String columFirst, String valueFirst, HttpServletRequest request) {
        return null;
    }

    @Override
    public ResponseEntity<Object> getAll(HttpServletRequest request) {
        List<ListMenuModel> listMenuModels = listMenuRepo.findAll();
        List<ListMenuDTO> listMenuDTOS =
                modelMapper.map(listMenuModels, new TypeToken<List<ListMenuDTO>>() {}.getType());

        if(listMenuDTOS == null || listMenuDTOS.isEmpty())
        {
            return new ResponseHandler().generateResponse("Data Tidak Ditemukan/Kosong",
                    HttpStatus.NOT_FOUND,
                    null,
                    "FV01001", request);//FAILED VALIDATION
        }

        return new ResponseHandler().generateResponse("Berhasil Diambil!",
                HttpStatus.OK,
                listMenuDTOS,
                null, request);
    }
}
