package com.restau.hcrestau.dto.menu;

public class MenuPaginationDTO {
    private Long idMenu;
    private String namaMenu;
    private Double hargaMenu;
    private String gambar;
    private Boolean available;

    public Long getIdMenu() {
        return idMenu;
    }

    public void setIdMenu(Long idMenu) {
        this.idMenu = idMenu;
    }

    public String getNamaMenu() {
        return namaMenu;
    }

    public void setNamaMenu(String namaMenu) {
        this.namaMenu = namaMenu;
    }

    public Double getHargaMenu() {
        return hargaMenu;
    }

    public void setHargaMenu(Double hargaMenu) {
        this.hargaMenu = hargaMenu;
    }

    public String getGambar() {
        return gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }

    public Boolean getAvailable() {
        return available;
    }

    public void setAvailable(Boolean available) {
        this.available = available;
    }
}
