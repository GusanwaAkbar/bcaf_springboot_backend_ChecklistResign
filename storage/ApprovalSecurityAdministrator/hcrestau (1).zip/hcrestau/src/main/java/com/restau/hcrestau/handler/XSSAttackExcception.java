package com.restau.hcrestau.handler;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.FORBIDDEN)
public class XSSAttackExcception extends RuntimeException{
    public XSSAttackExcception() {
    }

    public XSSAttackExcception(String message) {
        super(message);
    }
}
