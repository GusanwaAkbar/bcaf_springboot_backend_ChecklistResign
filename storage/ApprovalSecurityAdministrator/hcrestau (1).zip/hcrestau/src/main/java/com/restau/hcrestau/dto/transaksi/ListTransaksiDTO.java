package com.restau.hcrestau.dto.transaksi;

public class ListTransaksiDTO {

    //Diambil dari struk
    private Long idStruk;

    //Diambil dari menu
    private Long idMenu;

    private Integer jumlahMenu;

    public Long getIdStruk() {
        return idStruk;
    }

    public void setIdStruk(Long idStruk) {
        this.idStruk = idStruk;
    }

    public Long getIdMenu() {
        return idMenu;
    }

    public void setIdMenu(Long idMenu) {
        this.idMenu = idMenu;
    }

    public Integer getJumlahMenu() {
        return jumlahMenu;
    }

    public void setJumlahMenu(Integer jumlahMenu) {
        this.jumlahMenu = jumlahMenu;
    }

}
