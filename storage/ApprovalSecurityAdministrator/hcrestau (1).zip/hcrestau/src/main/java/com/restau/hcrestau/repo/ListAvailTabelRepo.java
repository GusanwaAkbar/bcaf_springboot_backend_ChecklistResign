package com.restau.hcrestau.repo;

import com.restau.hcrestau.model.ListAvailTabelModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ListAvailTabelRepo extends JpaRepository<ListAvailTabelModel, Long> {
    Optional<ListAvailTabelModel> findById(Long id);
    Optional<ListAvailTabelModel> findByIdAndIsAvail(Long id, Boolean avail);
    Page<ListAvailTabelModel> findById(Pageable pageable, Long id);

}
